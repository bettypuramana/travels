<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Cart_orders_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        
        //load database library
        $this->load->database();
    }

    var $table = 'cart_order';
    var $order = array('id' => 'desc');

    public function getCartOrderSellerCount($id='',$search='')
    {

        $this->db->select('cart_order.id as order_id,user_registration.prof_image as image,SUM(cart_order_sub.sub_total * cart_order_sub.qty) AS total_amt,cart_order.date,cart_order.type');
        $this->db->from('cart_order');
        $this->db->join('cart_order_sub', 'cart_order.id = cart_order_sub.order_id');
        $this->db->join('user_registration', 'cart_order.user_id = user_registration.id');
        $this->db->group_by('order_id');
        $this->db->order_by('cart_order.id','desc');

        if($search!='') {

        $this->db->where('cart_order_sub.seller_id',$id);
        $this->db->like('user_registration.phone',$search);
        $this->db->or_like('cart_order.id',$search);

        }

        $this->db->where('cart_order_sub.seller_id',$id);

        $query = $this->db->get();

        $categories = $query->num_rows();

        return $categories;
    }


    public function getCartOrderSellerWise($id='',$search='',$row='')
    {
        $row = ($row) * 10;

        $this->db->select('cart_order.id as order_id,user_registration.prof_image as image,cart_order.date,SUM(cart_order_sub.sub_total * cart_order_sub.qty) as total_amt');
        $this->db->from('cart_order');
        $this->db->join('cart_order_sub', 'cart_order.id = cart_order_sub.order_id');
        $this->db->join('user_registration', 'cart_order.user_id = user_registration.id');
        $this->db->group_by('order_id');
        $this->db->order_by('cart_order.id','desc');
        
        if($search!='') {

        $this->db->where('cart_order_sub.seller_id',$id);
        $this->db->like('user_registration.phone',$search);
        $this->db->or_like('cart_order.id',$search);

        }

        $this->db->where('cart_order_sub.seller_id',$id);

        $this->db->limit(10, $row);
        $query = $this->db->get();

        $categories = $query->result();

        $i=0;

        foreach($categories as $p_cat){

            $status = $this->getCartOrderStatusSub($p_cat->order_id,$id);

            $categories[$i]->status=$status[0]['status'];

            $i++;
        }

        return $categories;
    }

    public function getPrioritySellerCount($id='',$status='',$search='')
    {

        $this->db->select('cart_order.id as order_id,user_registration.prof_image as image,SUM(cart_order_sub.sub_total * cart_order_sub.qty) AS total_amt,cart_order.date,cart_order.type,cart_order.total_amt as deal_total');
        $this->db->from('cart_order');
        $this->db->join('cart_order_sub', 'cart_order.id = cart_order_sub.order_id');
        $this->db->join('user_registration', 'cart_order.user_id = user_registration.id');

        if($search!='') {

        $this->db->where('cart_order_sub.seller_id',$id);
        $this->db->where('cart_order_sub.status',$status);
        $this->db->like('user_registration.phone',$search);
        $this->db->or_like('cart_order.id',$search);

        }
        
        $this->db->where('cart_order_sub.status',$status);
        $this->db->where('cart_order_sub.seller_id',$id);
        $this->db->group_by('order_id');
        $this->db->order_by('cart_order.id','desc');
        $query = $this->db->get();

        $categories = $query->num_rows();

        return $categories;
    }

    public function getPrioritySellerWise($id='',$status='',$search='',$row='')
    {

        $row = ($row) * 10;

        $this->db->select('cart_order.id as order_id,user_registration.prof_image as image,SUM(cart_order_sub.sub_total * cart_order_sub.qty) AS total_amt,cart_order.date,cart_order.type,user_registration.phone');
        $this->db->from('cart_order');
        $this->db->join('cart_order_sub', 'cart_order.id = cart_order_sub.order_id');
        $this->db->join('user_registration', 'cart_order.user_id = user_registration.id');

        if($search!='') {

        $this->db->where('cart_order_sub.seller_id',$id);

        if($status!='-1') {
        
            $this->db->where('cart_order_sub.status',$status);
        }

        $this->db->like('user_registration.phone',$search);
        $this->db->or_like('cart_order.id',$search);

        }

        if($status!='-1') {
        
            $this->db->where('cart_order_sub.status',$status);
        }

        $this->db->where('cart_order_sub.seller_id',$id);
        $this->db->group_by('order_id');
        $this->db->order_by('cart_order.id','desc');
        $this->db->limit(10, $row);
        $query = $this->db->get();

        $categories = $query->result();

        $i=0;

        foreach($categories as $p_cat) {

            $status = $this->getCartOrderStatusSub($p_cat->order_id,$id);

            $categories[$i]->status=$status[0]['status'];

            $i++;
        }

        return $categories;
    }


    public function getCartOrderStockList($order_id='',$seller_id='')
    {
        $this->db->select('cart_order.id as order_id,cart_order.date,cart_order.user_id,SUM(cart_order_sub.sub_total * cart_order_sub.qty) AS total,user_registration.user_name,user_delivery_address.latitude as lat,user_delivery_address.longitude as lon,user_registration.email,user_delivery_address.name,user_delivery_address.pincode,user_delivery_address.address,user_delivery_address.land_mark,user_delivery_address.country,user_delivery_address.phone,user_delivery_address.alter_phone,register.loc_latitude,register.loc_longitude,register.location_name');
        $this->db->from('cart_order');
        $this->db->join('cart_order_sub', 'cart_order.id = cart_order_sub.order_id');
        $this->db->join('register', 'cart_order_sub.seller_id = register.reg_id');
        $this->db->join('user_registration', 'cart_order.user_id = user_registration.id');
        $this->db->join('user_delivery_address', 'cart_order.address_id = user_delivery_address.id');
        $this->db->where('cart_order.id',$order_id);
        $this->db->where('cart_order_sub.seller_id',$seller_id);
        $query = $this->db->get();

        $categories = $query->result();

        $i=0;

        foreach($categories as $p_cat){

            $status = $this->getCartOrderStatusSub($p_cat->order_id,$seller_id);

            $categories[$i]->status=$status[0]['status'];

            $categories[$i]->product = $this->getCartOrderStockListSub($p_cat->order_id,$seller_id);

            //$categories[$i]->address = $this->getCartOrderDeliverySub($id);

            $i++;
        }

        return $categories;
    }

    // public function getCartOrderDeliverySub($id='')
    // {
    //     $this->db->select('user_delivery_address.id,user_delivery_address.name,user_delivery_address.pincode,user_delivery_address.address,user_delivery_address.land_mark,user_delivery_address.country,user_delivery_address.phone,user_delivery_address.alter_phone');
    //     $this->db->from('user_delivery_address');
    //     $this->db->where('user_delivery_address.id',$id);

    //     $query = $this->db->get();

    //    return $query->result_array();
    // }

    public function getCartOrderStatusSub($order_id='',$seller_id='')
    {
        $this->db->select('cart_order_sub.status AS status');
        $this->db->from('cart_order_sub');
        $this->db->where('cart_order_sub.seller_id',$seller_id);
        $this->db->where('cart_order_sub.order_id',$order_id);
        $this->db->group_by('cart_order_sub.status');
        $query = $this->db->get();

        return $query->result_array();
    }

    public function getCartOrderStockListSub($order_id='',$seller_id)
    {
        $this->db->select('cart_order_sub.id,cart_stock.id as stock_id,cart_stock.stock_name,cart_stock.list_price, cart_order_sub.sub_total AS subtotal,cart_order_sub.qty,cart_order_sub.status,cart_product_image.image');
        $this->db->from('cart_order_sub');
        $this->db->join('cart_stock', 'cart_order_sub.stock_id = cart_stock.id');
        $this->db->join('cart_product_image', 'cart_stock.id = cart_product_image.stock_id');
        $this->db->group_by('cart_product_image.stock_id');
        $this->db->order_by('cart_order_sub.id','desc');
        $this->db->where('cart_order_sub.order_id',$order_id);
        $this->db->where('cart_order_sub.seller_id',$seller_id);

        $query = $this->db->get();

       return $query->result_array();
    }

    public function updateOrderDelivery($id,$seller_id,$status,$type='') { 

        $value = array('status' => $status );

        $this->db->update('cart_order_sub', $value, array('order_id'=>$id,'seller_id'=>$seller_id));

       if($this->db->affected_rows() > 0) {

            if($status==0) {

                $this->db->select('cart_order_sub.stock_id,cart_order_sub.qty');
                $this->db->from('cart_order_sub');
                $this->db->where('cart_order_sub.order_id',$id);
                $this->db->where('cart_order_sub.seller_id',$seller_id);
                $parent = $this->db->get();

                $categories = $parent->result();

                foreach ($categories as $index => $rows) {

                    $stock_id=$rows->stock_id;

                    $qty=$rows->qty;

                    $this->db->select('cart_stock.id,cart_stock.stock');//select each seller
                    $this->db->where('cart_stock.id',$stock_id);//select each seller
                    $query = $this->db->get('cart_stock');

                    if ($query->num_rows() > 0) {

                        foreach ($query->result_array() as $key => $stock_val) {

                            $stock_bal = $stock_val['stock'];//each seller wallet

                            $tot_stock_bal = ($stock_bal+$qty);//add input each seller
                        }

                        $value_tot_stock_bal= array('stock'=> $tot_stock_bal);

                        $this->db->where('id',$stock_id);
                        $this->db->update('cart_stock',$value_tot_stock_bal);
                    }

                }

            }

            return  true;

        }

        return  false;
    }

    public function SingleUserNotificationInsert($id='',$status='',$order_id='') { 

        if($status==2)
        {
            $value = array('notification' => "Your order ".$order_id." was delivered sucessfully",'user_id' => $id);
        }

        else if($status==0)
        {
            $value = array('notification' => "Your order ".$order_id." was cancelled by seller.",'user_id' => $id);
        }

        else{

             return false;  
        }
       
        $this->db->insert('sm_user_notification', $value);

        return true;                 
    }

    public function getCartOrderList($id='',$seller_id='')
    {
        $this->db->select('cart_order.id as order_id,cart_order_sub.stock_id,cart_stock.stock_name,cart_stock.discount,
        cart_order_sub.qty,cart_order_sub.sub_total,cart_order_sub.status,cart_order.date,register.bus_name,
        register.crop_image,11 as category_name');
        $this->db->from('cart_order');
        $this->db->join('cart_order_sub','cart_order.id = cart_order_sub.order_id');
        $this->db->join('cart_stock','cart_order_sub.stock_id = cart_stock.id');
        $this->db->join('register','cart_order_sub.seller_id = register.reg_id');
       // $this->db->join('category','register.bus_category = category.id');
        $this->db->where('cart_order_sub.seller_id',$seller_id);
        $this->db->where('cart_order.user_id',$id);
        $this->db->order_by('cart_order.id','desc');
        $query = $this->db->get();

        $categories = $query->result();
        
        $i=0;

        foreach($categories as $p_cat){

            $image = $this->getCartOrderListSub($p_cat->stock_id);

            $categories[$i]->image = $image[0]['image'];

            $i++;
        }
        
        return $categories; 
    }

    public function getCartOrderListSub($id='') {
   
        $this->db->select("cart_product_image.image");
        $this->db->from('cart_product_image');
        $this->db->where('cart_product_image.stock_id',$id);
        $this->db->order_by('cart_product_image.id','ASC');
        $this->db->limit(1);
        $query = $this->db->get();

        return $query->result_array();

    }

    public function getUserFollowBusList($id='')
    {
        $this->db->select('cart_seller_likes.id,register.reg_id,register.bus_name,register.location_name,user_registration.user_name,register.loc_latitude,register.loc_longitude,register.phone,register.crop_image');
        $this->db->from('cart_seller_likes');
        $this->db->join('user_registration', 'cart_seller_likes.user_id = user_registration.id');
        $this->db->join('register', 'cart_seller_likes.seller_id = register.reg_id');
        $this->db->where('register.status',1);
        $this->db->where('cart_seller_likes.user_id',$id);
        $this->db->where('cart_seller_likes.like_status',1);
        $query = $this->db->get();

        $categories = $query->result();

        $i=0;

        foreach($categories as $p_cat) {

            $total_like = $this->getUserFollowBusListSub($p_cat->reg_id);
            $categories[$i]->total_likes=$total_like[0]['like_count'];

            $i++;
        }
        
        return $categories;

    }

    public function getUserFollowBusListSub($id='')
    {
   
        $this->db->select('COUNT(cart_seller_likes.seller_id) AS like_count');
        $this->db->from('cart_seller_likes');
        $this->db->where('cart_seller_likes.seller_id',$id);
        $this->db->where('cart_seller_likes.like_status',1);
        $query = $this->db->get();

       return $query->result_array();
          
    }

    // public function getStockVariantList($id='',$option='',$user_id='')
    // {

    //     if(!empty($option))
    //     {

    //         $option = implode(',', $option);

    //         $cond="INNER JOIN cart_stock_option ON cart_stock.id=cart_stock_option.comb_id WHERE cart_stock_option.option_id in ($option) AND";
    //     }
           
    //     else
    //     {
    //         $cond='WHERE'; 
    //     }
   
    //     $this->db->select('cart_stock.id,cart_stock.stock_name,cart_stock.stock,cart_stock.price,cart_stock.list_price,cart_stock.discount,cart_product.id as product_id,cart_product.cat_id,cart_product.reg_id,cart_product.description,cart_product.warranty,register.bus_name,register.crop_image,register.location_name,register.pay_in_store,register.cash_on_del,register.online_pay');
    //     $this->db->from('cart_stock');
    //     $this->db->join('cart_product', 'cart_stock.product_id = cart_product.id');
    //     $this->db->join('register', 'cart_product.reg_id = register.reg_id');
    //     $this->db->where('cart_stock.id',$id);
    //     $parent = $this->db->get();

    //     $categories = $parent->result();

    //     $i=0;

    //     foreach($categories as $p_cat) {

    //         $wish_list = $this->getHomeUserwishListSub($p_cat->id,$user_id);

    //         $categories[$i]->wish_list=$wish_list[0]['wish_list'];

    //         $categories[0]->feature_name = $this->getProductIdWiseListfeatureSub($p_cat->product_id);

    //         $categories[$i]->option_name = $this->getProductIdWiseListOptionSub($p_cat->id);

    //         $categories[$i]->highlights = $this->getProductIdWiseListHighlightSub($p_cat->product_id);

    //         $categories[$i]->image_name = $this->getProductIdWiseListImageSub($p_cat->id);

    //         $categories[$i]->rating_product = $this->getProductIdWiseRatingSub($p_cat->id);

    //         $categories[0]->rate = $this->getProductRategrpSub($p_cat->id,$user_id);

    //         $categories[$i]->like_product = $this->getProductIdWiseLikeSub($p_cat->id,$user_id);

    //         $i++;
    //     }
        
    //     return $categories;
    // }

    // public function getHomeUserwishListSub($id='',$user_id='')
    // {
    //     $this->db->select('COUNT(cart_movetowishlist.move_id) AS wish_list');
    //     $this->db->from('cart_movetowishlist');
    //     $this->db->where('cart_movetowishlist.stock_id',$id);
    //     $this->db->where('cart_movetowishlist.user_id',$user_id);
    //     $this->db->where('cart_movetowishlist.status',1);
    //     $query = $this->db->get();

    //     return $query->result_array();
    // }

    // public function getProductIdWiseListfeatureSub($id='')
    // {
   
    //     $this->db->select('cart_feature_group.group_name,cart_feature.name,cart_stock_feature.feature_id');
    //     $this->db->from('cart_stock_feature');
    //     $this->db->join('cart_feature_variant', 'cart_stock_feature.feature_id = cart_feature_variant.f_var_id');
    //     $this->db->join('cart_feature', 'cart_feature_variant.f_id = cart_feature.id');
    //     $this->db->join('cart_feature_group', 'cart_feature.f_grp_id = cart_feature_group.grp_id');
    //     $this->db->where('cart_stock_feature.product_id',$id);

    //     $parent = $this->db->get();

    //     $categories = $parent->result();

    //     $i=0;

    //     foreach($categories as $p_cat){

    //         $categories[$i]->feature_varriant = $this->getFeatureWiseVariantSub($p_cat->feature_id);

    //         $i++;
    //     }
        
    //     return $categories;

    // }

    // public function getFeatureWiseVariantSub($id='')
    // {
    //     $this->db->select('cart_feature_variant.variants_name');
    //     $this->db->from('cart_feature_variant');
    //     $this->db->where('cart_feature_variant.f_var_id',$id);
    //     $this->db->order_by('cart_feature_variant.variants_name','ASC');
    //     $query = $this->db->get();

    //     return $query->result_array();
          
    // }

    // public function getProductIdWiseListOptionSub($id='')
    // {
   
    //     $this->db->select('cart_stock_option.option_id,options.name');
    //     $this->db->from('cart_stock_option');
    //     $this->db->join('options_type', 'cart_stock_option.option_id = options_type.opt_var_id');
    //     $this->db->join('options', 'options_type.opt_id = options.option_id');
    //     $this->db->where('cart_stock_option.comb_id',$id);
    //     $parent = $this->db->get();

    //     $categories = $parent->result();

    //     $i=0;

    //     foreach($categories as $p_cat) {

    //         $categories[$i]->option_varriant = $this->getOptionWiseVariantSub($p_cat->option_id);

    //         $i++;
    //     }
        
    //     return $categories;
    // }

    // public function getOptionWiseVariantSub($id='')
    // {
    //     $this->db->select('options_type.type_name');
    //     $this->db->from('options_type');
    //     $this->db->where('options_type.opt_var_id',$id);
    //     $this->db->order_by('type_name','ASC');
    //     $query = $this->db->get();

    //     $categories=$query->result();

    //     return $categories;

    // }

    // public function getProductIdWiseListHighlightSub($id='')
    // {
    //     $this->db->select('cart_highlights.highlights');
    //     $this->db->from('cart_highlights');
    //     $this->db->where('cart_highlights.product_id',$id);
    //     $this->db->order_by('cart_highlights.id','desc');
    //     $query = $this->db->get();

    //     return $query->result_array();
    // }
  
    // public function getProductIdWiseListImageSub($id='')
    // {
   
    //     $this->db->select('cart_product_image.id,cart_product_image.image');
    //     $this->db->from('cart_product_image');
    //     $this->db->where('cart_product_image.stock_id',$id);
    //     $query = $this->db->get();

    //     return $query->result_array();
          
    // }

    // public function getProductIdWiseRatingSub($id='')
    // {
   
    //     $this->db->select('COUNT(cart_rating.review) AS review_count,COALESCE(SUM(cart_rating.rating_score), 0) AS rating_count,ROUND(AVG(cart_rating.rating_score),1) as average');
    //     $this->db->from('cart_rating');
    //     $this->db->where('cart_rating.stock_id',$id);
    //     $parent = $this->db->get();

    //     $categories = $parent->result();

    //     $i=0;

    //     foreach($categories as $p_cat){

    //         $avg=$p_cat->average;

    //         $categories[$i]->review = $this->getProductRateReviewSub($id);

    //         $i++;
    //     }
    //    // $avg_value=array('rating'=>$avg);

    //     //$this->db->where('id',$id);
    //    // $this->db->update('cart_stock',$avg_value);
    
    //     return $categories;

    // }

    // public function getProductRateReviewSub($id='')
    // {
   
    //     $this->db->select("cart_rating.review,cart_rating.rating_score,DATE_FORMAT(cart_rating.date_rated,'%d %b,%Y') AS rating_date");
    //     $this->db->from('cart_rating');
    //     $this->db->where('cart_rating.stock_id',$id);
    //     $query = $this->db->get();

    //     return $query->result_array();
          
    // }

    //  public function getProductRategrpSub($id='')
    // {
   
    //         $this->db->select('cart_rating.rating_score,COUNT(cart_rating.rating_score) AS count');
    //         $this->db->from('cart_rating');
    //         $this->db->group_by('cart_rating.rating_score');
    //         $this->db->where('cart_rating.stock_id',$id);
    //         $query = $this->db->get();

    //        return $query->result_array();
          

    // }


    // public function getProductIdWiseLikeSub($id='',$user_id='')
    // {

    //     $this->db->select('COUNT(cart_likes.stock_id) AS product_like');
    //     $this->db->from('cart_likes');
    //     $this->db->where('cart_likes.stock_id',$id);
    //     $parent = $this->db->get();

    //     $categories = $parent->result();

    //     $i=0;

    //     foreach($categories as $p_cat){

    //         $categories[$i]->like = $this->getUserWiseLikeSub($id,$user_id);

    //         $i++;
    //     }
    
    //     return $categories;

    // }

    // public function getUserWiseLikeSub($id='',$user_id='')
    // {
   
    //         $this->db->select('COUNT(cart_likes.user_id) AS user_like');
    //         $this->db->from('cart_likes');
    //         $this->db->where('cart_likes.user_id',$user_id);
    //         $this->db->where('cart_likes.stock_id',$id);
    //         $query = $this->db->get();

    //        return $query->result_array();
          

    // }

    public function putOrderDeliveryAddress($data='',$id='') { 

        if($id) {

            $this->db->where('id',$id);
            $this->db->update('user_delivery_address',$data);
        }
        else{

            $this->db->insert('user_delivery_address', $data);
        }

        return true; 

    }

    public function getDeliveryAddressData($id='',$seller_id='')
    {
        $this->db->select('user_delivery_address.id,user_registration.user_name,user_delivery_address.name,user_delivery_address.address,user_delivery_address.pincode,user_delivery_address.land_mark,user_delivery_address.country,user_delivery_address.phone,user_delivery_address.alter_phone');
        $this->db->from('user_delivery_address');
        $this->db->join('user_registration', 'user_delivery_address.user_id = user_registration.id');
        $this->db->order_by('user_delivery_address.id','ASC');
        $this->db->where('user_delivery_address.user_id',$id);
        $this->db->where('user_delivery_address.seller_id',$seller_id);
        $query = $this->db->get();

        $categories = $query->result();

        return $categories;
    }

    public function getIdWiseDeliveryAddress($id='')
    {
        $this->db->select('user_delivery_address.id,user_registration.user_name,user_delivery_address.name,user_delivery_address.address,user_delivery_address.pincode,user_delivery_address.land_mark,user_delivery_address.country,user_delivery_address.phone,user_delivery_address.alter_phone');
        $this->db->from('user_delivery_address');
        $this->db->join('user_registration', 'user_delivery_address.user_id = user_registration.id');
        $this->db->order_by('user_delivery_address.id','ASC');
        $this->db->where('user_delivery_address.id',$id);
        $query = $this->db->get();

        $categories = $query->result();

        return $categories;
    }

    public function deleteDeliveryAddress($id){
        
        $delete = $this->db->delete('user_delivery_address',array('id'=>$id));
        return ($this->db->affected_rows() != 1) ? false : true;
    }

    public function getCartOrderUserWise($id='',$search='',$row='')
    {
        $row = ($row) * 10;

        $this->db->select('cart_order.id as order_id,user_registration.prof_image as image,SUM(cart_order_sub.sub_total * cart_order_sub.qty) AS total_amt,cart_order.date');
        $this->db->from('cart_order');
        $this->db->join('cart_order_sub', 'cart_order.id = cart_order_sub.order_id');
        $this->db->join('user_registration', 'cart_order.user_id = user_registration.id');
       

        if($search!='') {
            
        $this->db->where('cart_order.user_id',$id);
        $this->db->like('user_registration.phone',$search);
        $this->db->or_like('cart_order.id',$search);
        }

        $this->db->where('cart_order.user_id',$id);
        $this->db->group_by('order_id');
        $this->db->order_by('cart_order.id','desc');
        $this->db->limit(10, $row);
        $query = $this->db->get();

        $categories = $query->result();

        return $categories;
    }

    public function getUserOrderDetails($order_id='')
    {
        $this->db->select('cart_order.id as order_id,cart_order.date,cart_order.user_id,SUM(cart_order_sub.sub_total * cart_order_sub.qty) AS total,user_registration.user_name,user_registration.phone,user_registration.email');
        $this->db->from('cart_order');
        $this->db->join('cart_order_sub', 'cart_order.id = cart_order_sub.order_id');
        $this->db->join('user_registration', 'cart_order.user_id = user_registration.id');
        $this->db->where('cart_order.id',$order_id);
        $query = $this->db->get();

        $categories = $query->result();

        $i=0;

        foreach($categories as $p_cat){

           // $status = $this->getCartOrderStatusSub($p_cat->order_id,$seller_id);

           // $categories[$i]->status=$status[0]['status'];

            $categories[$i]->product = $this->getUserOrderDetailsSub($p_cat->order_id);

            $i++;
        }

        return $categories;
    }

    public function getUserOrderDetailsSub($order_id='')
    {
        $this->db->select('cart_order_sub.id,cart_stock.id as stock_id,cart_stock.stock_name,cart_order_sub.sub_total as list_price,SUM(cart_order_sub.sub_total * cart_order_sub.qty) AS subtotal,cart_order_sub.qty,cart_order_sub.status,cart_product_image.image');
        $this->db->from('cart_order_sub');
        $this->db->join('cart_stock', 'cart_order_sub.stock_id = cart_stock.id');
        $this->db->join('cart_product_image', 'cart_stock.id = cart_product_image.stock_id');
        $this->db->group_by('cart_product_image.stock_id');
        $this->db->order_by('cart_order_sub.id','desc');
        $this->db->where('cart_order_sub.order_id',$order_id);

        $query = $this->db->get();

       return $query->result_array();
    }

    public function cancelOrderUser($order_id='',$user_id='') { 

        $value = array('status' => '0' );

        $this->db->update('cart_order', $value, array('id'=>$order_id,'user_id'=>$user_id));

        $this->db->update('cart_order_sub', $value, array('order_id'=>$order_id));

       if($this->db->affected_rows() > 0) {

            return  true;

        }
        else{

            return  false;
        }

    }
    
    public function getCartOrderUserWiseData($seller_id='',$user_id='')
    {
        $this->db->select('cart_order.id as order_id,cart_order.date,cart_order.user_id,user_delivery_address.latitude as lat,user_delivery_address.longitude as lon,user_delivery_address.name,user_delivery_address.pincode,user_delivery_address.address,user_delivery_address.land_mark,user_delivery_address.country,user_delivery_address.phone,user_delivery_address.alter_phone');
        $this->db->from('cart_order');
        $this->db->join('cart_order_sub', 'cart_order.id = cart_order_sub.order_id');
        $this->db->join('user_delivery_address', 'cart_order.address_id = user_delivery_address.id');
        $this->db->where('cart_order.user_id',$user_id);
        $this->db->where('cart_order_sub.seller_id',$seller_id);
        $this->db->group_by('cart_order.id');
        $query = $this->db->get();

        $categories = $query->result();
        
        $i=0;

        foreach($categories as $p_cat){
            
            $categories[$i]->total = $this->getCartOrderUserWiseTotalSub($p_cat->order_id,$seller_id);

            $categories[$i]->status = $this->getCartOrderUserWiseDataSubStatusSub($p_cat->order_id,$seller_id);

            $categories[$i]->product = $this->getCartOrderUserWiseDataSub($p_cat->order_id,$seller_id);

            $i++;
        }

        return $categories;
    }
    
    public function getCartOrderUserWiseTotalSub($order_id='',$seller_id='')
    {
        $this->db->select('SUM(cart_order_sub.sub_total * cart_order_sub.qty) AS total');
        $this->db->from('cart_order_sub');
        $this->db->where('cart_order_sub.seller_id',$seller_id);
        $this->db->where('cart_order_sub.order_id',$order_id);
        $this->db->group_by('cart_order_sub.status');
        $query = $this->db->get();

        if ($query->num_rows() > 0) {

            $result = $query->result_array()[0]['total'];
        }
        else{

            $result = 0;

        }

        return $result;
    }

    public function getCartOrderUserWiseDataSubStatusSub($order_id='',$seller_id='')
    {
        $this->db->select('cart_order_sub.status AS status');
        $this->db->from('cart_order_sub');
        $this->db->where('cart_order_sub.seller_id',$seller_id);
        $this->db->where('cart_order_sub.order_id',$order_id);
        $this->db->group_by('cart_order_sub.status');
        $query = $this->db->get();

        if ($query->num_rows() > 0) {

            $result = $query->result_array()[0]['status'];
        }
        else{

            $result = 0;

        }

        return $result;
    }

    public function getCartOrderUserWiseDataSub($order_id='',$seller_id)
    {
        $this->db->select('cart_order_sub.id,cart_stock.id as stock_id,cart_stock.stock_name,cart_stock.list_price, cart_order_sub.sub_total AS subtotal,cart_order_sub.qty,cart_order_sub.status,cart_product_image.image');
        $this->db->from('cart_order_sub');
        $this->db->join('cart_stock', 'cart_order_sub.stock_id = cart_stock.id');
        $this->db->join('cart_product_image', 'cart_stock.id = cart_product_image.stock_id');
        $this->db->group_by('cart_product_image.stock_id');
        $this->db->order_by('cart_order_sub.id','desc');
        $this->db->where('cart_order_sub.order_id',$order_id);
        $this->db->where('cart_order_sub.seller_id',$seller_id);

        $query = $this->db->get();

       return $query->result_array();
    }
    public function putOrderCancelUser($user_id='',$order_id='',$stock_id='') { 

        $data  = array('status' => 0);

        $this->db->where('stock_id',$stock_id);
        $this->db->where('order_id',$order_id);
        $this->db->update('cart_order_sub',$data);
        
        return true; 

    }


}

?>