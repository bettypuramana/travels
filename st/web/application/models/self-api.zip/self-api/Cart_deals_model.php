<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Cart_deals_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        
        //load database library
        $this->load->database();
    }

    public function insertOfferData($data) { 

        if(!array_key_exists('created_at', $data)){
            $data['created_at'] = date("Y-m-d H:i:s");
        }

        $insert =$this->db->insert('offers', $data);

        if($insert)
        {
            return true;
        } 
        else
        {
            return false;
        }
    }
    
    public function getDealProductListByArea($seller_id='',$latitude='',$longitude='',$radius='',$date='') { 
   
        $parent = $this->db->query("
        SELECT cart_deals.id,z.product_name,z.reg_id,z.cat_id,cart_deals.offer_price,cart_deals.image as deal_image,cart_deals.offer_starting,
        cart_deals.offer_ending,cart_deals.caption,cart_deals.description,cart_deals.offer_type,discount_offer.type,cart_deals.status,
        cart_stock.id as stock_id,cart_stock.stock_name,cart_stock.price,cart_stock.list_price,cart_stock.stock,register.bus_name,
        register.crop_image
    
        FROM cart_product AS z
        JOIN cart_stock ON z.id=cart_stock.product_id
        JOIN cart_deals ON cart_stock.id=cart_deals.stock_id
        JOIN register ON cart_deals.seller_id = register.reg_id
        JOIN discount_offer ON cart_deals.offer_type = discount_offer.id
       
        WHERE cart_deals.offer_starting < '$date' 
        AND cart_deals.offer_ending > '$date'
        AND cart_stock.status=1 
       
        ");

        $categories = $parent->result();

        $i=0;

        foreach($categories as $p_cat){

           // $rate = $this->getDirectTypeRatingSub($p_cat->id,$p_cat->offer_type);
            $rate =array();
            $categories[$i]->rating=$rate[0]['average'];

            $images = $this->getProductDirectDealsSub($p_cat->stock_id);

            $categories[$i]->image=$images[0]['image'];

            $i++;
        }
           
        return $categories;
    }
    public function getProductDirectDealsSub($id='')
    {
        $this->db->select('cart_product_image.image');
        $this->db->from('cart_product_image');
        $this->db->where('cart_product_image.stock_id',$id);
        $this->db->group_by('cart_product_image.stock_id');

        $query = $this->db->get();

        return $query->result_array();
    }
     public function getDirectTypeRatingSub($id='',$type='') {

        $this->db->select('ROUND(AVG(deal_rating.rating_score),1) as average');
        $this->db->from('deal_rating');
        $this->db->where('deal_rating.deal_id',$id);
        $this->db->where('deal_rating.type',$type);
        $this->db->where('deal_rating.status',1);
        $query = $this->db->get();

        return $query->result_array();
    }
    
    public function getBundelProductListByArea($seller_id='',$latitude='',$longitude='',$radius='',$date) {
   
        $this->db->select('cart_combo_offer.id,cart_combo_offer.offer_price,cart_combo_offer.image as deal_image,cart_combo_offer.offer_start,cart_combo_offer.offer_end,cart_combo_offer.caption,
        cart_combo_offer.description,cart_combo_offer.offer_type,0 as qty_min,1000 as qty_max
        ,100 as type,1 as bus_name,1 as crop_image,cart_combo_offer.status');
        $this->db->from('cart_combo_offer');
        $this->db->where('cart_combo_offer.offer_start <', $date);
        $this->db->where('cart_combo_offer.offer_end >', $date);
        $query = $this->db->get();

        $categories = $query->result();
        $i=0;
        foreach($categories as $p_cat){

           // $rate = $this->getDirectTypeRatingSub($p_cat->id,$p_cat->offer_type);
           $rate=array();

            $categories[$i]->rating=$rate[0]['average'];

            $categories[$i]->product = $this->getBundelProductListByAreaSub($p_cat->id,$latitude,$longitude,$radius);

            $categories[$i]->offer = [];

            $i++;
        }

        return $categories;
    }
    public function getBundelProductListByAreaSub($id='',$latitude='',$longitude='',$radius='') {
   
        $parent = $this->db->query("
        SELECT z.id,cart_combo_products.id as cart_bundle_productid,z.product_name,
        z.reg_id,z.cat_id,cart_stock.id as stock_id,cart_stock.stock_name,
        cart_stock.price,cart_stock.list_price,cart_stock.stock,cart_product_image.image
        
        FROM cart_product AS z
        JOIN cart_stock ON z.id=cart_stock.product_id
        JOIN cart_combo_products ON cart_stock.id=cart_combo_products.stock_id
        JOIN cart_product_image ON cart_stock.id = cart_product_image.stock_id
        
        WHERE cart_combo_products.deal_id=$id
       
        AND cart_stock.status=1 
        GROUP BY cart_product_image.stock_id
        ");

        $categories = $parent->result();
        
        return $categories;
    }
    
     public function getBuyGetListByArea($seller_id='',$latitude='',$longitude='',$radius='',$date) {
   
        $this->db->select('cart_buyget_offer.id,cart_buyget_offer.buy_qty,cart_buyget_offer.get_qty,NULL AS offer_price,cart_buyget_offer.image as deal_image,cart_buyget_offer.offer_starting,cart_buyget_offer.offer_ending,cart_buyget_offer.caption,cart_buyget_offer.description,cart_buyget_offer.offer_type,cart_buyget_offer.qty_min,cart_buyget_offer.qty_max,discount_offer.type,register.bus_name,register.crop_image,cart_buyget_offer.status', FALSE);
        $this->db->from('cart_buyget_offer');
        $this->db->join('discount_offer', 'cart_buyget_offer.offer_type = discount_offer.id');
        $this->db->join('register', 'cart_buyget_offer.seller_id = register.reg_id');
        $this->db->where('cart_buyget_offer.offer_starting <', $date);
        $this->db->where('cart_buyget_offer.offer_ending >', $date);
        $query = $this->db->get();

        $categories = $query->result();
        $i=0;
        foreach($categories as $p_cat){

           // $rate = $this->getDirectTypeRatingSub($p_cat->id,$p_cat->offer_type);
           $rate = array();

            $categories[$i]->rating=$rate[0]['average'];

            $categories[$i]->product = $this->getBuyGetListByAreaSub($p_cat->id,$latitude,$longitude,$radius);

            $categories[$i]->offer = $this->getBuyGetListByAreaOfferSub($p_cat->id,$latitude,$longitude,$radius);

            $i++;
        }

        return $categories;
    }

    public function getBuyGetListByAreaSub($id='',$latitude='',$longitude='',$radius='') {

        $parent = $this->db->query("
        SELECT z.id,cart_buy_products.id as cart_buy_productid,z.product_name,z.reg_id,z.cat_id,
        cart_stock.id as stock_id,cart_stock.stock_name,cart_stock.price,cart_stock.list_price,
        cart_stock.stock,cart_product_image.image
        
        FROM cart_product AS z
        JOIN cart_stock ON z.id=cart_stock.product_id
        JOIN cart_buy_products ON cart_stock.id=cart_buy_products.stock_id
        JOIN cart_product_image ON cart_stock.id = cart_product_image.stock_id
        
        WHERE cart_buy_products.buyget_id=$id
        
        AND cart_stock.status =1
        GROUP BY cart_product_image.stock_id
        ");

        $categories = $parent->result();

        return $categories;
    }

    public function getBuyGetListByAreaOfferSub($id='',$latitude='',$longitude='',$radius='') {
   
        $parent = $this->db->query("
        SELECT z.id,cart_get_products.id as cart_combo_offer_id,z.product_name,z.reg_id,z.cat_id,
        cart_stock.id as stock_id,cart_stock.stock_name,cart_stock.price,cart_stock.list_price,cart_stock.stock,
        cart_product_image.image
        
        FROM cart_product AS z
        JOIN cart_stock ON z.id=cart_stock.product_id
        JOIN cart_get_products ON cart_stock.id=cart_get_products.stock_id
        JOIN cart_product_image ON cart_stock.id = cart_product_image.stock_id
        
        WHERE cart_get_products.buyget_id=$id
        
        AND cart_stock.status =1 
        GROUP BY cart_product_image.stock_id
        ");

        $categories = $parent->result();
        
        return $categories;
    }


    public function insertDealRatingData($data) 
    { 

        if(!array_key_exists('date_rated', $data)){
            $data['date_rated'] = date("Y-m-d H:i:s");
        }

        $insert =$this->db->insert('deal_rating', $data);

        if($insert)
        {
            return true;
        } 
        else
        {
            return false;
        }
    }

    public function getDelasProducts($seller_id='') {
   
        $this->db->select('cart_stock.id as stock_id,cart_stock.stock_name,cart_stock.price,cart_stock.list_price,cart_stock.stock,cart_stock.discount,cart_stock.unit,cart_product.id as product_id,cart_product.product_name,cart_category.cat_id,cart_category.cat_name');
        $this->db->from('cart_product');
        $this->db->join('cart_category', 'cart_product.cat_id = cart_category.cat_id');
        $this->db->join('cart_stock', 'cart_product.id = cart_stock.product_id');
        $this->db->where('cart_product.reg_id',$seller_id);
        $this->db->where("cart_stock.status",1);
        $this->db->order_by('cart_stock.stock_name','asc');
        $query = $this->db->get();

        $categories = $query->result();

        $i=0;

        foreach($categories as $p_cat) {

            $categories[$i]->image = $this->getImageDataSub($p_cat->stock_id);

            $i++;
        }

        return $categories;

    }

    public function getImageDataSub($id='') {
   
        $this->db->select("cart_product_image.image");
        $this->db->from('cart_product_image');
        $this->db->where('cart_product_image.stock_id',$id);
        $this->db->order_by('cart_product_image.id','ASC');
        $this->db->limit(1);
        $query = $this->db->get();

        if($query->num_rows() > 0 )
        {

            $image=$query->result_array()[0]['image'];

            return $image;
        }
        else{

            return "no image";

        }

    }

      public function getDailyOfferByIdData($id='') {
   
        $this->db->select('offers.id,offers.caption,offers.image,offers.start_date,offers.exp_date,offers.seller_id');
        $this->db->from('offers');
        $this->db->where('offers.id',$id);
        $query = $this->db->get();

        $categories = $query->result();

     
        return $categories;

    }

    public function getDailyOfferProductData($id='',$search='',$row='') {

        $row = ($row) * 10;

        $date = date('Y-m-d G:i:s', time());
   
        $this->db->select('offers.id,offers.caption,offers.image,offers.start_date,offers.exp_date,offers.created_at,offers.seller_id');
        $this->db->from('offers');
        $this->db->where('offers.seller_id',$id);

        if($search!='') {
            
            $this->db->where('offers.seller_id',$id);
            $this->db->like('offers.caption',$search);
        
        }
        $this->db->limit(10, $row);
        $query = $this->db->get();

        $categories = $query->result();

     
        return $categories;

    }

    public function getDailyOfferProductDataCount($id='',$search='') {

        $date = date('Y-m-d G:i:s', time());
   
        $this->db->select('offers.id,offers.caption,offers.image,offers.start_date,offers.exp_date,offers.created_at,offers.seller_id');
        $this->db->from('offers');
        $this->db->where('offers.seller_id',$id);

        if($search!='') {
            
            $this->db->where('offers.seller_id',$id);
            $this->db->like('offers.caption',$search);
        
        }
        
        $query = $this->db->get();

        $categories = $query->num_rows();

     
        return $categories;

    }
    
    public function deleteOfferProductData($id='') {
   
        $this->db->where('offers.id',$id);
        $this->db->delete('offers');
     
        return true;

    }


}

?>