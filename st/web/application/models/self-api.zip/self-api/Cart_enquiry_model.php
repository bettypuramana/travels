<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Cart_enquiry_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        
        //load database library
        $this->load->database();
    }

    var $table = 'cart_enquiry';
    var $order = array('id' => 'desc');

    public function insertCartEnquiry($data='',$user_id='',$seller_id='') 
    { 

        $enquiry_value= array('user_id' => $user_id,'seller_id' => $seller_id,'created_at' => date("Y-m-d H:i:s"));

        $this->db->insert('cart_enquiry', $enquiry_value);

        $insert_id = $this->db->insert_id();

        if ($insert_id) { 

        	foreach ($data['data'] as $key => $res) {

        		$name = $res['name'];
        		$qty  = $res['quantity'];
        		$unit = $res['unit'];

        		$value= array('enq_id' => $insert_id,'product_name' => $name,'qty' => $qty,'unit' => $unit);

        		$this->db->insert('cart_enquiry_products', $value);
        	}

        return true;
        
        }
        else {

            return false;
        }
    }
    
    public function getEnquiryData($user_id='',$seller_id='')
    {
        $this->db->from('cart_enquiry');
        $this->db->where('cart_enquiry.user_id',$user_id);
        $this->db->where('cart_enquiry.seller_id',$seller_id);
        $query = $this->db->get();

        $categories = $query->result();

        $i=0;

        foreach($categories as $p_cat){

            $categories[$i]->sub = $this->getEnquirySellerDataSub($p_cat->id);

            $i++;
        }

        return $categories;

    }

    public function getEnquirySellerData($seller_id='',$status='')
    {
        $this->db->select('cart_enquiry.id as enquiry_id,cart_enquiry.created_at,cart_enquiry.status,user_registration.user_name,user_registration.phone,user_registration.location,user_registration.address,user_registration.prof_image,user_registration.gender,user_registration.lat,user_registration.lon');
        $this->db->from('cart_enquiry');
        $this->db->join('user_registration', 'cart_enquiry.user_id = user_registration.id');
        $this->db->where('cart_enquiry.seller_id',$seller_id);
        $this->db->where('cart_enquiry.status',$status);
        $this->db->order_by('cart_enquiry.id','DESC');
        $query = $this->db->get();

        $categories = $query->result();

        $i=0;
        foreach($categories as $p_cat){

            $categories[$i]->sub = $this->getEnquirySellerDataSub($p_cat->enquiry_id);

            $i++;
        }

        return $categories;

    }

    public function getEnquirySellerDataSub($id='') {
   
        $this->db->select('cart_enquiry_products.id,cart_enquiry_products.product_name,cart_enquiry_products.qty,cart_enquiry_products.unit');
        $this->db->from('cart_enquiry_products');
        $this->db->where('cart_enquiry_products.enq_id',$id);
        $query = $this->db->get();

        return $query->result_array();
    }
    
    
    public function getEnquiryByIdData($enquiry_id='')
    {
        $this->db->select('cart_enquiry.id as enquiry_id,cart_enquiry.created_at,cart_enquiry.status,user_registration.id as user_id,user_registration.user_name,user_registration.phone,user_registration.location,user_registration.address,user_registration.prof_image,user_registration.gender,user_registration.lat,user_registration.lon,register.loc_latitude,register.loc_longitude');
        $this->db->from('cart_enquiry');
        $this->db->join('user_registration', 'cart_enquiry.user_id = user_registration.id');
        $this->db->join('register', 'cart_enquiry.seller_id = register.reg_id');
        $this->db->where('cart_enquiry.id',$enquiry_id);
        $this->db->order_by('cart_enquiry.id','DESC');
        $query = $this->db->get();

        $categories = $query->result();

        $i=0;

        foreach($categories as $p_cat){

            $categories[$i]->sub = $this->getEnquirySellerDataSub($p_cat->enquiry_id);

            $i++;
        }

        return $categories;

    }
    
    public function SingleSellerNotificationInsert($id='',$message='') { 

        $value = array('notification' => $message,'seller_id' => $id,'module_type' =>2);

        $this->db->insert('seller_notification', $value);

        if($this->db->affected_rows() > 0){

        return true;     

        }
        else{

            return  false;
        }            
    }

                   
}

?>