<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

Class User_register_model extends MY_model {

    public function __construct() {

        parent::__construct();
        $this->load->database();
    }

    var $table = 'user_registration';

    public function insertUserRegister($value,$id='',$phone='',$company_name='',$position='',$work_date_from='',$work_date_to='')
    {

        $update = $this->db->update($this->table, $value, array('id'=>$id));
        
        $insert_id = $id;
        
        if($phone) {

            $this->db->where('user_id',$insert_id);
            $this->db->delete('user_phone');

            foreach( $phone as $phones ) 
            {
                $value_phone= array('user_id' => $insert_id,'number' => $phones);
                $this->db->insert('user_phone', $value_phone);
            }

        }


        if($company_name) {

            foreach( $company_name as $index1 => $company_names ) {

                $value_course= array('user_reg_id' => $insert_id,'comp_name' => $company_names,'position' => $position[$index1],'from_date' => $work_date_from[$index1],'to_date' => $work_date_to[$index1]);
                $this->db->insert('work_det', $value_course);
            }

        }

        if ($this->db->affected_rows() > 0)
        {
            return TRUE;
        }
        else
        {
            return FALSE;
        }

    }

    public function insertUserPersonal($value,$action,$ed_id='')
    {
        if($action==0){

            $this->db->insert('education_det', $value);
        } else {

            $this->db->update('education_det', $value, array('id'=>$ed_id));
        }
        if($this->db->affected_rows() > 0) {

            return TRUE;
        } else {

            return FALSE;
        }

    }

    public function updateUserLocation($data='',$id='') {

        $this->db->where('id',$id);
        $this->db->update($this->table,$data);

        if($this->db->affected_rows() > 0) {

            return TRUE;
            
        } else {

            return FALSE;
        }

    }
   
    public function getUserEducaDetail($id='')
    {
        $this->db->from('education_det');
        if ($id != '')

        $this->db->where('user_reg_id', $id);
        $query = $this->db->get();
        return $query->result_array();
    }

    public function deleteUserEduDetail($id){

        $delete = $this->db->delete('education_det',array('id'=>$id));
        return $delete?true:false;
    }

    
}