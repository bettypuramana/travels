<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Cart_product_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        
        //load database library
        $this->load->database();
    }

    var $table = 'cart_product';
    var $order = array('id' => 'desc');
    
       public function getCatProductListByArea($seller_id='') {

        $this->db->select('cart_category.cat_id,cart_category.cat_name as cat_name,cart_category.parent_id,cart_category.image, cart_category.cat_icon as cat_icon,
        cart_category.parent_id as cat_parent,1 as shop_type,1 as active_status');
        $this->db->from('register');
        $this->db->join('cart_category', 'cart_category.seller_id = register.reg_id');
        //$this->db->join('home_seller_category', 'shop_type_category.cat_id = home_seller_category.cat_id','left');
       // $this->db->where('shop_type_category.parent =',0);
        $this->db->where('register.reg_id',$seller_id);
       // $this->db->where('home_seller_category.seller_id',$seller_id);
        $this->db->order_by('cart_category.cat_id','asc');
        $query  = $this->db->get();

        $result = $query->result();
    
        return $result;  
        
    }
    public function getCatServiceListByArea($seller_id='') {

        $this->db->select('service_category.cat_id,service_category.display_name as cat_name,service_category.parent_id,service_category.cat_icon');
        $this->db->from('service_category');
        $this->db->join('service', 'service_category.cat_id = service.cat_id');
        $this->db->where('service.reg_id',$seller_id);
        $this->db->order_by('service_category.cat_name','ASC');
        $this->db->group_by('service_category.cat_id');
        $query  = $this->db->get();

        $result = $query->result();
    
        return $result;  
        
    }

    public function getProductCatWise($seller_id='',$cat_id='')
    {

        if( !empty($cat_id) ) {

            $query =$this->db->query("SELECT p6.parent_id as parent6_id, p5.parent_id as parent5_id, p4.parent_id as parent4_id, p3.parent_id as parent3_id, p2.parent_id as parent2_id, p1.parent_id as parent_id, p1.cat_id as cat_id, p1.cat_name from cart_category p1 left join cart_category p2 on p2.cat_id = p1.parent_id left join cart_category p3 on p3.cat_id= p2.parent_id left join cart_category p4 on p4.cat_id= p3.parent_id left join cart_category p5 on p5.cat_id= p4.parent_id left join cart_category p6 on p6.cat_id =p5.parent_id where $cat_id in (p1.parent_id, p2.parent_id, p3.parent_id, p4.parent_id, p5.parent_id, p6.parent_id) order by 1, 2, 3, 4, 5");

            $result = $query->result();

            $category= array();
            
            $f=0;
            foreach ($result as $row) {

               $category[$f]=$row->cat_id;

               $f++;
            }

            array_unshift($category,$cat_id);

            $comma_list = implode(",", $category);

            $cat_condition="AND z.cat_id IN($comma_list)";

        }
        else
        {
            $cat_condition="";
        }


        $parent = $this->db->query("SELECT cart_stock.id,z.cat_id,z.reg_id,cart_stock.price,cart_stock.list_price,cart_stock.stock_name,cart_stock.url_slug,cart_stock.discount,cart_stock.stock,register.bus_name,register.crop_image,z.description
        FROM cart_product AS z  
        JOIN cart_stock ON z.id=cart_stock.product_id
        JOIN register ON z.reg_id=register.reg_id
        WHERE z.reg_id=$seller_id
        AND cart_stock.status=1 
        $cat_condition
        ORDER BY cart_stock.id");
        $categories = $parent->result();

        $i=0;
        
        foreach($categories as $p_cat){

            $encrypted_id = base64_encode($p_cat->id . SALT_KEY);

            $link='http://onlister.com/product/'.$p_cat->url_slug.'?OL='.$encrypted_id;

            $categories[$i]->share_link=$link;

            $categories[$i]->sub = $this->getProductImageByAreaSub($p_cat->id);
            $i++;
        }

        return $categories;

    }

    public function getProductImageByAreaSub($id='') {
   
        $this->db->select('cart_product_image.image');
        $this->db->from('cart_product_image');
        $this->db->where('cart_product_image.stock_id',$id);
        $query = $this->db->get();

        return $query->result_array();
    }
    
  public function  getstoreList()
  {
       $this->db->select('store.id,store.location');
        $this->db->from('store');
       $query = $this->db->get();

        return $query->result_array();
  }

    // public function getSellerPriorityBannerList($seller_id='',$latitude='',$longitude='',$radius='') {

    //     $query = $this->db->query("SELECT id,banner_name,image,priority,distance

    //     FROM (
    //     SELECT z.id,z.banner_name,z.image,z.priority,p.radius,p.distance_unit
    //     * DEGREES(ACOS(COS(RADIANS(p.latpoint))
    //     * COS(RADIANS(z.latitude))
    //     * COS(RADIANS(p.longpoint - z.longitude))
    //     + SIN(RADIANS(p.latpoint))
    //     * SIN(RADIANS(z.latitude)))) AS distance
    //     FROM shop_banner AS z
    //     JOIN (   /* these are the query parameters */
    //     SELECT  $latitude  AS latpoint,  $longitude AS longpoint,
    //     $radius AS radius,      111.045 AS distance_unit
    //     ) AS p ON 1=1
    //     WHERE z.latitude
    //     BETWEEN p.latpoint  - (p.radius / p.distance_unit)
    //     AND p.latpoint  + (p.radius / p.distance_unit)
    //     AND z.longitude
    //     BETWEEN p.longpoint - (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
    //     AND p.longpoint + (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
    //     AND z.banner_type='seller'
    //     AND z.type_id=$seller_id
    //     ) AS d
    //     WHERE distance <= radius
    //     ORDER BY priority ASC");
        
    //     $categories = $query->result();
        
    //     return $categories;   
    // }
    
    public function getSellerPriorityBannerList($seller_id='') {
   
        $this->db->select('cart_banner.id,cart_banner.banner_name,cart_banner.image,cart_banner.priority');
        $this->db->from('cart_banner');
        $this->db->where('cart_banner.seller_id',$seller_id);
        $this->db->order_by('cart_banner.priority','ASC');
        $query = $this->db->get();

        return $query->result_array();
    }

   /* public function getPopularProductList($seller_id='',$user_id='',$latitude='',$longitude='',$radius='',$cat_id='')
    {

        if( !empty($cat_id) ) {

            $query =$this->db->query("SELECT p6.parent_id as parent6_id, p5.parent_id as parent5_id, p4.parent_id as parent4_id, p3.parent_id as parent3_id, p2.parent_id as parent2_id, p1.parent_id as parent_id, p1.cat_id as cat_id, p1.cat_name from cart_category p1 left join cart_category p2 on p2.cat_id = p1.parent_id left join cart_category p3 on p3.cat_id= p2.parent_id left join cart_category p4 on p4.cat_id= p3.parent_id left join cart_category p5 on p5.cat_id= p4.parent_id left join cart_category p6 on p6.cat_id =p5.parent_id where $cat_id in (p1.parent_id, p2.parent_id, p3.parent_id, p4.parent_id, p5.parent_id, p6.parent_id) order by 1, 2, 3, 4, 5");

            $result = $query->result();

            $category= array();
        
            $f=0;

            foreach ($result as $row) {

                $category[$f]=$row->cat_id;

                $f++;
            }

            array_unshift($category,$cat_id);

            $comma_list = implode(",", $category);

            $cat_condition="AND cart_category.cat_id IN($comma_list)";
        }
        else
        {
            $cat_condition="";
        }


        $parent = $this->db->query("SELECT id,price,list_price,stock_name,url_slug,discount,stock,reg_id,bus_name,cat_id,cat_name,description, distance

        FROM (
        SELECT cart_stock.id,cart_stock.price as list_price,cart_stock.list_price as price,cart_stock.discount,cart_stock.stock,cart_stock.stock_name,cart_stock.url_slug,z.reg_id,register.bus_name,z.cat_id,cart_category.cat_name, z.description,p.radius,p.distance_unit
        * DEGREES(ACOS(COS(RADIANS(p.latpoint))
        * COS(RADIANS(z.latitude))
        * COS(RADIANS(p.longpoint - z.longitude))
        + SIN(RADIANS(p.latpoint))
        * SIN(RADIANS(z.latitude)))) AS distance
        FROM cart_product AS z
        INNER JOIN cart_stock ON z.id=cart_stock.product_id
        INNER JOIN cart_category ON z.cat_id=cart_category.cat_id
        INNER JOIN register ON z.reg_id=register.reg_id
        JOIN (   /* these are the query parameters */
       // SELECT  $latitude  AS latpoint,  $longitude AS longpoint,
       // $radius AS radius,111.045 AS distance_unit
        /*) AS p ON 1=1
        WHERE z.latitude
        BETWEEN p.latpoint  - (p.radius / p.distance_unit)
        AND p.latpoint  + (p.radius / p.distance_unit)
        AND z.longitude
        BETWEEN p.longpoint - (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        AND p.longpoint + (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        $cat_condition
        AND cart_stock.status=1 
        AND z.reg_id=$seller_id
        ) AS d
        WHERE distance <= radius
        ORDER BY rand() LIMIT 6");

        $categories = $parent->result();

        $i=0;
        foreach($categories as $p_cat){

            $encrypted_id = base64_encode($p_cat->id . SALT_KEY);

            $link='http://onlister.com/product/'.$p_cat->url_slug.'?OL='.$encrypted_id;

            $categories[$i]->share_link=$link;

            $categories[$i]->cart_status = $this->getStockCartStatusSub($user_id,$p_cat->id);

            $categories[$i]->image_name = $this->getProductImageSub($p_cat->id);

            $i++;
        }
        
        return $categories;    
    }*/
     public function getPopularProductList($seller_id='',$user_id='',$latitude='',$longitude='',$radius='',$cat_id='')
    {

        if( !empty($cat_id) ) {

            $query =$this->db->query("SELECT p6.parent_id as parent6_id, p5.parent_id as parent5_id, p4.parent_id as parent4_id, p3.parent_id as parent3_id, p2.parent_id as parent2_id, p1.parent_id as parent_id, p1.cat_id as cat_id, p1.cat_name from cart_category p1 left join cart_category p2 on p2.cat_id = p1.parent_id left join cart_category p3 on p3.cat_id= p2.parent_id left join cart_category p4 on p4.cat_id= p3.parent_id left join cart_category p5 on p5.cat_id= p4.parent_id left join cart_category p6 on p6.cat_id =p5.parent_id where $cat_id in (p1.parent_id, p2.parent_id, p3.parent_id, p4.parent_id, p5.parent_id, p6.parent_id) order by 1, 2, 3, 4, 5");

            $result = $query->result();

            $category= array();
        
            $f=0;

            foreach ($result as $row) {

                $category[$f]=$row->cat_id;

                $f++;
            }

            array_unshift($category,$cat_id);

            $comma_list = implode(",", $category);

            $cat_condition="AND cart_category.cat_id IN($comma_list)";
        }
        else
        {
            $cat_condition="";
        }


        $parent = $this->db->query("
        SELECT cart_stock.id,cart_stock.price as list_price,cart_stock.list_price as price,cart_stock.discount,cart_stock.stock,cart_stock.stock_name,cart_stock.url_slug,z.reg_id,
        register.bus_name,z.cat_id,cart_category.cat_name, z.description
        FROM cart_product AS z
        INNER JOIN cart_stock ON z.id=cart_stock.product_id
        INNER JOIN cart_category ON z.cat_id=cart_category.cat_id
        INNER JOIN register ON z.reg_id=register.reg_id
        WHERE z.reg_id=$seller_id
        AND cart_stock.status=1
        $cat_condition
        ORDER BY rand() LIMIT 6");
        
        
        

        $categories = $parent->result();

        $i=0;
        foreach($categories as $p_cat){

            $encrypted_id = base64_encode($p_cat->id . SALT_KEY);

            $link='http://onlister.com/product/'.$p_cat->url_slug.'?OL='.$encrypted_id;

            $categories[$i]->share_link=$link;

            $categories[$i]->cart_status = $this->getStockCartStatusSub($user_id,$p_cat->id);

            $categories[$i]->image_name = $this->getProductImageSub($p_cat->id);

            $i++;
        }
        
        return $categories;    
    }

    public function getStockCartStatusSub($user_id='',$stock_id='') {

        $this->db->where('user_id',$user_id);
        $this->db->where('stock_id',$stock_id);
        $query = $this->db->get('sm_cart_addtocart');

        $res=$query->num_rows();

        return $res;
    }

    public function getProductImageSub($id='')
    {
        $this->db->select('cart_product_image.image');
        $this->db->from('cart_product_image');
        $this->db->where('cart_product_image.stock_id',$id);
        $this->db->group_by('cart_product_image.stock_id');
        $query = $this->db->get();
        return $query->result_array();
    }

  
    public function getUserDetailsList($id='',$seller_id='')
    {
   
        $this->db->select('user_registration.id,user_registration.user_name,user_registration.phone,user_registration.email,user_registration.whatsapp,
        user_registration.location,user_registration.joining_date,
        user_registration.gender,user_registration.address,user_registration.address3,user_registration.bio_quto,user_registration.prof_image,user_registration.cover_image,
        user_registration.wallet_bal');
        $this->db->from('user_registration');
        $this->db->order_by('user_registration.id','desc');
        $this->db->where('user_registration.id',$id);
        $query = $this->db->get();

        $categories = $query->result();

        $i=0;
        foreach($categories as $p_cat){

            $categories[$i]->bus_count = $this->getUserDetailsListSub($p_cat->phone);
            $categories[$i]->cart_count = $this->getUserCartCountSub1($id,$seller_id);
            $categories[$i]->notif_count = $this->getUserNotificationCountSub($p_cat->id);
            $categories[$i]->phone_numbers = $this->getUserDetailsPhoneSub($p_cat->id);

            $i++;
        }
        
        return $categories; 

    }

    public function getUserNotificationCountSub($id='')
    {
        $this->db->from('sm_user_notification');
        $this->db->where('sm_user_notification.user_id',$id);
        $this->db->where('sm_user_notification.status',0);
        $query = $this->db->get();
        return $query->num_rows();
    }

    public function getUserDetailsListSub($id='')
    {
        $this->db->from('register_userlist');
        $this->db->where('register_userlist.phone',$id);
        $query = $this->db->get();

        return $query->num_rows();

    }

    public function getUserCartCountSub1($id='',$seller_id='')
    {
        $this->db->from('sm_cart_addtocart');
        $this->db->where('user_id',$id);
        $this->db->where('seller_id',$seller_id);
        $query = $this->db->get();

        $res=$query->num_rows();

        return $res;

    }
     public function getUserCartCountSub($id='',$seller_id='')
    {
        $this->db->select('COUNT(sm_cart_addtocart.user_id) AS cart_count');
        $this->db->from('sm_cart_addtocart');
        $this->db->where('sm_cart_addtocart.seller_id',$seller_id);
        $this->db->where('sm_cart_addtocart.user_id',$id);
        $query = $this->db->get();

        return $query->result_array();

    }
    
     

    public function getUserDetailsPhoneSub($id='')
    {
        $this->db->select('user_phone.number');
        $this->db->from('user_phone');
        $this->db->where('user_phone.user_id',$id);
        $query = $this->db->get();

        return $query->result_array();

    }
    
    public function getUserWiseCartCount($user_id='',$seller_id='') {

        $this->db->where('user_id',$user_id);
        $this->db->where('seller_id',$seller_id);
        $query = $this->db->get('sm_cart_addtocart');

        $res=$query->num_rows();

        return $res;
    }

    public function insertRatingData($data) { 

        if(!array_key_exists('date_rated', $data)){
            $data['date_rated'] = date("Y-m-d H:i:s");
        }

        $this->db->where('user_id',$data['user_id']);
        $this->db->where('stock_id',$data['stock_id']);
        $query = $this->db->get('cart_rating');

        if ($query->num_rows() >= 1){

            $this->db->where('user_id',$data['user_id']);
            $this->db->where('stock_id',$data['stock_id']);
            $this->db->update('cart_rating',$data);

        }
        else{

            $insert =$this->db->insert('cart_rating', $data);

        }

       return ($this->db->affected_rows() != 1) ? false : true;
      
    }

    public function SingleSellerNotificationInsert($id='',$message='') { 

        $value = array('notification' => $message,'seller_id' => $id);

        $this->db->insert('seller_notification', $value);

        if($this->db->affected_rows() > 0){

        return true;     

        }
        else{

            return  false;
        }            
    }

    public function MultiSellerNotificationInsert($id='',$message='') { 


     foreach ($id as $key => $sellers) {

           $value = array('notification' => $message,'seller_id' => $sellers);

           $this->db->insert('seller_notification', $value);

        }

    }

    public function insertLikeData($data) 
    { 
        $this->db->trans_start();

        $this->db->where('user_id',$data['user_id']);
        $this->db->where('stock_id',$data['stock_id']);
        $query = $this->db->get('cart_likes');

        if ($query->num_rows() >= 1){

            $this->db->where('user_id',$data['user_id']);
            $this->db->where('stock_id',$data['stock_id']);
            $this->db->update('cart_likes',$data);
        }

        else{

        $this->db->insert('cart_likes', $data);
        }

        $this->db->trans_complete();

        return true;
       
    }

    public function insertSellerLikeData($data) 
    { 

        $this->db->where('user_id',$data['user_id']);
        $this->db->where('seller_id',$data['seller_id']);
        $query = $this->db->get('cart_seller_likes');

        if ($query->num_rows() >= 1){

            $this->db->where('user_id',$data['user_id']);
            $this->db->where('seller_id',$data['seller_id']);
            $this->db->update('cart_seller_likes',$data);
        }

        else{

            $this->db->insert('cart_seller_likes', $data);
        }

         return true;

       
    }


    public function insertSellerRatingData($data) { 

        if(!array_key_exists('date_rated', $data)){
            $data['date_rated'] = date("Y-m-d H:i:s");
        }

        $this->db->where('user_id',$data['user_id']);
        $this->db->where('seller_id',$data['seller_id']);
        $query = $this->db->get('cart_seller_review');

        if ($query->num_rows() >= 1){

            $this->db->where('user_id',$data['user_id']);
            $this->db->where('seller_id',$data['seller_id']);
            $this->db->update('cart_seller_review',$data);

        }
        else{

            $insert =$this->db->insert('cart_seller_review', $data);

        }

        return ($this->db->affected_rows() != 1) ? false : true;

    }

    public function insertAddCartQtyData($data) 
    { 

        if(!array_key_exists('date', $data)){
            $data['date'] = date("Y-m-d H:i:s");
        }

        $this->db->select('stock');
        $this->db->where('id',$data['stock_id']);
        $query = $this->db->get('cart_stock');

        $result=$query->result()[0]->stock;

        if($data['qty'] > $result){
           return false;
        }
        else{

            $this->db->where('user_id',$data['user_id']);
            $this->db->where('seller_id',$data['seller_id']);
            $this->db->where('stock_id',$data['stock_id']);
            $query = $this->db->get('sm_cart_addtocart');

            if ($query->num_rows() > 0){

                foreach ($query->result_array() as $key => $value) {

                    $id = $value['id'];
                   // $newqty = $value['qty']+$data['qty'];
                }

                $value_Cart= array('seller_id' => $data['seller_id'],'user_id' => $data['user_id'],'stock_id' => $data['stock_id'],'qty'=> $data['qty']);

                $this->db->where('id',$id);
                $this->db->update('sm_cart_addtocart',$value_Cart);

                return true;
            }
            else{

                $insert =$this->db->insert('sm_cart_addtocart', $data);
                return true;
            }

        }
   
    }

    public function insertAddCartData($data)
    { 
        if(!array_key_exists('date', $data)){
            $data['date'] = date("Y-m-d H:i:s");
        }

        $this->db->where('user_id',$data['user_id']);
        $this->db->where('stock_id',$data['stock_id']);
        $query = $this->db->get('sm_cart_addtocart');

        if ($query->num_rows() > 0) {

            foreach ($query->result_array() as $key => $value) {

                $id = $value['id'];
            }

            $value_Cart= array('user_id' => $data['user_id'],'stock_id' => $data['stock_id']);

            $this->db->where('id',$id);
            $this->db->update('sm_cart_addtocart',$value_Cart);

            return true;
        }
        else{

            $insert =$this->db->insert('sm_cart_addtocart', $data);
            return true;
        }
    }

    public function getCartCount($id='',$seller_id='') {

        $this->db->where('user_id',$id);
        $this->db->where('seller_id',$seller_id);
        $query = $this->db->get('sm_cart_addtocart');

        $res=$query->num_rows();

        return $res;
    }

    public function insertMoveToWishList($data) 
    {
        if(!array_key_exists('date', $data)){
            $data['date'] = date("Y-m-d H:i:s");
        }

        $this->db->trans_begin();

        $this->db->where('user_id',$data['user_id']);
        $this->db->where('stock_id',$data['stock_id']);
        $this->db->delete('sm_cart_addtocart');

        $this->db->where('user_id',$data['user_id']);
        $this->db->where('stock_id',$data['stock_id']);
        $query = $this->db->get('cart_movetowishlist');

        if ($query->num_rows() >= 1){

            $this->db->where('user_id',$data['user_id']);
            $this->db->where('stock_id',$data['stock_id']);
            $this->db->update('cart_movetowishlist',$data);
        }
        else {

            $this->db->insert('cart_movetowishlist', $data);
        }

        $this->db->trans_complete();

        return TRUE;

    }

    public function insertLikeToWishList($data) 
    {
        if(!array_key_exists('date', $data)){
            $data['date'] = date("Y-m-d H:i:s");
        }

        $this->db->trans_begin();

        $this->db->where('user_id',$data['user_id']);
        $this->db->where('stock_id',$data['stock_id']);
        $query = $this->db->get('cart_movetowishlist');

        if ($query->num_rows() >= 1){

            $this->db->where('user_id',$data['user_id']);
            $this->db->where('stock_id',$data['stock_id']);
            $this->db->update('cart_movetowishlist',$data);
        }
        else {

            $this->db->insert('cart_movetowishlist', $data);
        }

        $this->db->trans_complete();

        return TRUE;
    }

    public function checkOUtOfStock($stock_id='',$qty='')
    {
          foreach($stock_id as  $index => $products) {

            $this->db->where('id',$products);
            $this->db->where('status',1);
            $query = $this->db->get('cart_stock');

            if(isset($query->result()[0]->stock)) {

                if($query->result()[0]->stock >= $qty[$index]) {

                 $data[]= "stock:".$query->result()[0]->id;

                }

                else{

                    $data[]= "out stock:".$query->result()[0]->id;

                }

            }

        }

        return $data;
    }

    public function insertAddCartOrder($data,$stock_id='',$seller_id='',$qty='',$sub_total='') {

        if(!array_key_exists('date', $data)) {

            $data['date'] = date("Y-m-d H:i:s");
        }
       
        $insert =$this->db->insert('cart_order', $data);
        
        $insert_id = $this->db->insert_id();

        if ($insert) { 

            foreach($stock_id as  $index => $products) {

                $value_order= array('order_id' => $insert_id,'stock_id' => $products,'qty' => $qty[$index],'sub_total' => $sub_total[$index],'seller_id' => $seller_id);

                $this->db->insert('cart_order_sub', $value_order);

                $this->db->select('cart_stock.id,cart_stock.stock');//select each seller
                $this->db->where('cart_stock.id',$products);//select each seller
                $query = $this->db->get('cart_stock');

                if ($query->num_rows() > 0) { 

                    foreach ($query->result_array() as $key => $stock_val) {

                        $stock_bal = $stock_val['stock'];//each seller wallet

                        $tot_stock_bal = ($stock_bal-$qty[$index]);//add input each seller
                    }

                    $value_tot_stock_bal= array('stock'=> $tot_stock_bal);

                    $this->db->where('id',$products);
                    $this->db->update('cart_stock',$value_tot_stock_bal);

                }
            } 

            $this->db->select('register.reg_id,register.wallet_bal');//select each seller
            $this->db->where('register.reg_id',$seller_id);//select each seller
            $query = $this->db->get('register');

            if ($query->num_rows() > 0) {

                foreach ($query->result_array() as $key => $value1) {

                    $buswallet_bal = $value1['wallet_bal'];//each seller wallet

                    $tot_buswallet_bal = $buswallet_bal+$data['total_amt'];//add input each seller
                }

                $value_buswallet= array('wallet_bal'=> $tot_buswallet_bal);

                $this->db->where('reg_id',$seller_id);
                $this->db->update('register',$value_buswallet);

            }

            $this->db->where('user_registration.id',$data['user_id']);
            $query = $this->db->get('user_registration');

            if ($query->num_rows() > 0) {

                foreach ($query->result_array() as $key => $value) {

                    $wallet_bal = $value['wallet_bal'];
                    $tot_wallet_bal = $wallet_bal-$data['total_amt'];
                }

                $value_wallet= array('wallet_bal'=> $tot_wallet_bal);

                $this->db->where('id',$data['user_id']);
                $this->db->update('user_registration',$value_wallet);

            }

            $this->db->where('user_id', $data['user_id']);
            $this->db->delete('sm_cart_addtocart'); 

            return true;

        }

        else{

            return FALSE;
        }

    }

    public function insertRecentlyViewed($data) 
    { 
        $insert =$this->db->insert('cart_recently_view', $data);

        if($insert)
        {
            return true;
        } 
        else
        {
            return false;
        }
    }

    public function deleteRecentlyViewed()
    {

         $query = $this->db->query("DELETE FROM cart_recently_view WHERE viewdate < DATE_ADD(NOW(), INTERVAL -5 DAY)");

    }

    public function insertSuggestedPost($data) 
    { 

        $this->db->where('user_id', $data['user_id']);
        $query = $this->db->get('cart_user_mostlook');

        if ( $query->num_rows() > 0 ) 
        {

            $this->db->where('user_id', $data['user_id'])->update('cart_user_mostlook', $data);
            return true;

        } else {

             $insert =$this->db->insert('cart_user_mostlook', $data);
             return true;
        }
      
    }

    public function putPaymentModeData($cart_id='',$mode='') {

        $data = array('payment_mode' => $mode);

        $update = $this->db->update('sm_cart_addtocart', $data, array('id'=>$cart_id));

        if ($this->db->affected_rows() > 0) {

            return true;
        }
        else{

            return false;
        }

    }

    public function insertProductCountData($click_count,$id) { 
       
        if($click_count) {

            $this->db->from("cart_product");
            $this->db->where('id',$id);
            $query = $this->db->get();

            $count=$query->result_array()[0]['click_count'];

            $total_count=$count+$click_count;

            $value = array('click_count' => $total_count);

            $this->db->where('id', $id);
            $this->db->update('cart_product', $value);

            return true;                 


        } else{

            return false;

        }

    }

    public function getProductListByAreaCount($cat_id='',$latitude='',$longitude='',$radius='',$data='',$seller_id='') {

        $min_pr=$data['min_pr'];
        $max_pr=$data['max_pr'];

        $option = implode(',', $data['options']);

        $feature=implode(',', $data['features']);
        
        if( !empty($cat_id) )
        {

            $query =$this->db->query("SELECT p6.parent_id as parent6_id, p5.parent_id as parent5_id, p4.parent_id as parent4_id, p3.parent_id as parent3_id, p2.parent_id as parent2_id, p1.parent_id as parent_id, p1.cat_id as cat_id, p1.cat_name from cart_category p1 left join cart_category p2 on p2.cat_id = p1.parent_id left join cart_category p3 on p3.cat_id= p2.parent_id left join cart_category p4 on p4.cat_id= p3.parent_id left join cart_category p5 on p5.cat_id= p4.parent_id left join cart_category p6 on p6.cat_id =p5.parent_id where $cat_id in (p1.parent_id, p2.parent_id, p3.parent_id, p4.parent_id, p5.parent_id, p6.parent_id) order by 1, 2, 3, 4, 5");
    
            $result = $query->result();
    
            $category= array();
            
            $f=0;
            foreach ($result as $rows) {
    
               $category[$f]=$rows->cat_id;
    
               $f++;
            }
    
            array_unshift($category,$cat_id);
    
            $comma_list = implode(",", $category);
            
            $cat_condition="AND cart_category.cat_id IN($comma_list)";
        }
         else
        {
            $cat_condition="";
        }

        if( !empty($option) && !empty($feature) )
        {

            $cond=" INNER JOIN cart_stock_option ON cart_stock.id=cart_stock_option.comb_id INNER JOIN cart_stock_feature ON z.id=cart_stock_feature.product_id WHERE cart_stock_option.option_id in ($option) AND cart_stock_feature.feature_id in ($feature) AND";
        }

        else if(!empty($option))
        {

            $cond="INNER JOIN cart_stock_option ON cart_stock.id=cart_stock_option.comb_id WHERE cart_stock_option.option_id in ($option) AND";

        }
           
        else if(!empty($feature))
        {

            $cond="INNER JOIN cart_stock_feature ON z.id=cart_stock_feature.product_id WHERE cart_stock_feature.feature_id in ($feature) AND";
        }

        else
        {
            $cond='WHERE'; 
        }

        if( !empty($min_pr) && !empty($max_pr) )
        {
            $price_condition="AND cart_stock.list_price BETWEEN $min_pr AND $max_pr";
        }
        else
        {
            $price_condition="";
        }


        $parent = $this->db->query("
        SELECT cart_stock.id
        FROM cart_product AS z
        JOIN cart_stock ON z.id=cart_stock.product_id
        JOIN register ON z.reg_id=register.reg_id
        JOIN cart_category ON z.cat_id=cart_category.cat_id
        WHERE
        
         cart_stock.status=1 
        
        $price_condition
        $cat_condition
        GROUP BY cart_stock.id
        ");
        $categories = $parent->num_rows();
   
        return $categories;
    }

    public function getProductListByArea($cat_id='',$latitude='',$longitude='',$radius='',$row='',$order='',$data='',$seller_id='')
    {
        
        $min_pr=$data['min_pr'];
        $max_pr=$data['max_pr'];

        $option = implode(',', $data['options']);

        $feature=implode(',', $data['features']);
        
        if( !empty($cat_id) )
        {

            $query =$this->db->query("SELECT p6.parent_id as parent6_id, p5.parent_id as parent5_id, p4.parent_id as parent4_id, p3.parent_id as parent3_id, p2.parent_id as parent2_id, p1.parent_id as parent_id, p1.cat_id as cat_id, p1.cat_name from cart_category p1 left join cart_category p2 on p2.cat_id = p1.parent_id left join cart_category p3 on p3.cat_id= p2.parent_id left join cart_category p4 on p4.cat_id= p3.parent_id left join cart_category p5 on p5.cat_id= p4.parent_id left join cart_category p6 on p6.cat_id =p5.parent_id where $cat_id in (p1.parent_id, p2.parent_id, p3.parent_id, p4.parent_id, p5.parent_id, p6.parent_id) order by 1, 2, 3, 4, 5");
    
            $result = $query->result();
    
            $category= array();
            
            $f=0;
            foreach ($result as $rows) {
    
               $category[$f]=$rows->cat_id;
    
               $f++;
            }
    
            array_unshift($category,$cat_id);
    
            $comma_list = implode(",", $category);
    
            $cat_condition="AND cart_category.cat_id IN($comma_list)";
        
        }
         else
        {
            $cat_condition="";
        }


        if( !empty($option) && !empty($feature) )
        {

            $cond=" INNER JOIN cart_stock_option ON cart_stock.id=cart_stock_option.comb_id INNER JOIN cart_stock_feature ON z.id=cart_stock_feature.product_id WHERE cart_stock_option.option_id in ($option) AND cart_stock_feature.feature_id in ($feature) AND";
        }

        else if(!empty($option))
        {

            $cond="INNER JOIN cart_stock_option ON cart_stock.id=cart_stock_option.comb_id WHERE cart_stock_option.option_id in ($option) AND";

        }
           
        else if(!empty($feature))
        {

            $cond="INNER JOIN cart_stock_feature ON z.id=cart_stock_feature.product_id WHERE cart_stock_feature.feature_id in ($feature) AND";
        }

        else
        {
            $cond='WHERE'; 
        }

        if( !empty($min_pr) && !empty($max_pr) )
        {
            $price_condition="AND cart_stock.list_price BETWEEN $min_pr AND $max_pr";
        }
        else
        {
            $price_condition="";
        }


        $row = ($row) * 10;

        $parent = $this->db->query("
        SELECT cart_stock.id,cart_stock.stock_name,cart_stock.price,cart_stock.list_price,cart_stock.stock,
        cart_stock.discount,cart_stock.status,z.reg_id,z.product_name,
        z.id as product_id,10000 as rating,z.cat_id,cart_category.cat_name,
        register.bus_name as seller_name,1 as seller_image,z.description
        
        FROM cart_product AS z
        
        JOIN cart_stock ON z.id=cart_stock.product_id
        JOIN register ON z.reg_id=register.reg_id
        JOIN cart_category ON z.cat_id=cart_category.cat_id
        WHERE cart_stock.status=1
        $price_condition
        $cat_condition
        GROUP BY cart_stock.id
        
        ORDER BY $order LIMIT $row,10");
        $categories = $parent->result();
     
        $i=0;
        foreach($categories as $p_cat){

            //$rating = $this->getProductListByAreaRatingSub($p_cat->id);
            $rating = array();

            //$categories[$i]->rating_product=$rating[0]['average'];
             $categories[$i]->rating_product=0;

            $categories[$i]->image_name = $this->getProductListByAreaSub($p_cat->id);

            $i++;
        }
        
        return $categories;
    }

    public function getProductListByAreaRatingSub($id='')
    {
   
        $this->db->select('ROUND(AVG(cart_rating.rating_score),1) as average');
        $this->db->from('cart_rating');
        $this->db->where('cart_rating.stock_id',$id);
        $parent = $this->db->get();

        $categories = $parent->result_array();
    
        return $categories;
    }

    public function getProductListByAreaSub($id='')
    {
        $this->db->select('cart_product_image.image');
        $this->db->from('cart_product_image');
        $this->db->where('cart_product_image.stock_id',$id);
        $query = $this->db->get();

        return $query->result_array();
    }


    public function getProductReviewStatus($user_id='',$stock_id='') 
    {

        $this->db->select('cart_order_sub.id');
        $this->db->from('cart_order');
        $this->db->join('cart_order_sub', 'cart_order.id = cart_order_sub.order_id');
        $this->db->where('cart_order_sub.status',2);
        $this->db->where('cart_order_sub.stock_id',$stock_id);
        $this->db->where('cart_order.user_id',$user_id);
        $query = $this->db->get();

        if ($query->num_rows() >= 1) {

            return 1;
        }

        else{

            return 0;
        }

    }

    public function getProductIdWiseList($id='',$user_id='',$option='',$product_id='',$seller_id='')
    {

        if( !empty($option) ) {

            sort($option);

            $option = implode(',', $option);

            $this->db->select('options_type.opt_var_id as var_id,options_type.type_name as var_name');
            $this->db->from('options_type');
            $this->db->where("options_type.opt_var_id IN (".$option.")",NULL, false);
            $query = $this->db->get();

            $res=$query->result();

            $uniq_value=$product_id;

            foreach($res as  $index => $result) 
            {

                $uniq_value=$uniq_value.$result->var_name;
            }

            $this->db->select('cart_stock_option.comb_id');
            $this->db->from('cart_stock_option');
            $this->db->where('cart_stock_option.uneek',$uniq_value);
            $this->db->group_by('cart_stock_option.comb_id');
            $parent = $this->db->get();

            $categories = $parent->result();

            if(empty($categories)) {

                return false;

            }

            else{

                 $res_val=$categories[0]->comb_id;

            }

        }

        $this->db->select('cart_stock.id,cart_stock.link,cart_stock.stock_name,cart_stock.stock,cart_stock.price,cart_stock.list_price,cart_stock.discount,cart_product.id as product_id,cart_product.cat_id,cart_product.reg_id,cart_product.description,cart_product.warranty,register.bus_name,register.crop_image,register.location_name,register.pay_in_store,register.cash_on_del,register.online_pay');
        $this->db->from('cart_stock');
        $this->db->join('cart_product', 'cart_stock.product_id = cart_product.id');
        $this->db->join('register', 'cart_product.reg_id = register.reg_id');
        
        if( !empty($option) ) {

            $this->db->where('cart_stock.id',$res_val);
        }
        else{

            $this->db->where('cart_stock.id',$id);
        }
        
        $parent = $this->db->get();

        $categories = $parent->result();

        $i=0;

        foreach($categories as $p_cat) {
            
            $cart_count =$this->getUserCartCountSub($user_id,$seller_id);

            $categories[$i]->cart_count = $cart_count[0]['cart_count'];

            $wish_list = $this->getHomeUserwishListSub($p_cat->id,$user_id);

            $categories[$i]->wish_list=$wish_list[0]['wish_list'];

            $categories[$i]->feature_name = $this->getProductIdWiseListfeatureSub($p_cat->product_id);

            $categories[$i]->feature_txt = $this->getProductIdWisefeatureTxtSub($p_cat->product_id);

            //$categories[$i]->option_name = $this->getProductIdWiseListOptionSub($p_cat->id);

            $categories[$i]->highlights = $this->getProductIdWiseListHighlightSub($p_cat->product_id);

            $categories[$i]->image_name = $this->getProductIdWiseListImageSub($p_cat->id);

            $categories[$i]->rating_product = $this->getProductIdWiseRatingSub($p_cat->id);

            $categories[$i]->rate = $this->getProductRategrpSub($p_cat->id,$user_id);

            $categories[$i]->like_product = $this->getProductIdWiseLikeSub($p_cat->id,$user_id);

            $categories[$i]->option_name = $this->getProductIdWiseListOptionSub($p_cat->id,$p_cat->product_id,$id);
             //$categories[$i]->option_name = $this->getProductIdWiseListOptionSub($p_cat->id);

            $categories[$i]->selected_option_name = $this->getSelectedWiseListOptionSub($p_cat->id);

            $i++;
        }

        return $categories;
    }

    public function getSelectedWiseListOptionSub($id)
    {

        $this->db->select('cart_stock.id as stock_id,cart_stock.stock_name,options_type.opt_id,options_type.opt_var_id,options_type.type_name,options_type.color_name');
        $this->db->from('cart_product');
        $this->db->join('cart_stock', 'cart_product.id = cart_stock.product_id');
        $this->db->join('cart_stock_option', 'cart_stock.id = cart_stock_option.comb_id');
        $this->db->join('options_type', 'cart_stock_option.option_id = options_type.opt_var_id');
        $this->db->where('cart_stock_option.comb_id',$id);

        $query = $this->db->get();

        $categories=$query->result();

        return $categories;

    }


    public function getProductIdWiseListOptionSub($id='',$product_id='',$stock_id)
    {

        $this->db->select("options_type.opt_id,cart_stock_option.option_id,options.name");
        $this->db->from('cart_stock');
        $this->db->join('cart_stock_option', 'cart_stock.id = cart_stock_option.comb_id');
        $this->db->join('options_type', 'cart_stock_option.option_id = options_type.opt_var_id');
        $this->db->join('options', 'options_type.opt_id = options.option_id');
        $this->db->where('cart_stock_option.comb_id',$id);
        $this->db->group_by('options.option_id');

        $parent = $this->db->get();

        $categories = $parent->result();

        $i=0;

        foreach($categories as $p_cat) {

            $categories[$i]->option_varriant = $this->getSellerTestListSubSub($p_cat->opt_id,$product_id,$id,$stock_id);

            $i++;
        }
        
        return $categories;

    }


    public function getSellerTestListSubSub($opt_id='',$product_id,$id,$stock_id)
    {

        $this->db->select('IF(cart_stock.id='.$id.',"1", 0) "status",cart_stock.id as stock_id,cart_stock.stock_name,options_type.opt_id,options_type.opt_var_id,options_type.type_name,options_type.color_name');
        $this->db->from('cart_product');
        $this->db->join('cart_stock', 'cart_product.id = cart_stock.product_id');
        $this->db->join('cart_stock_option', 'cart_stock.id = cart_stock_option.comb_id');
        $this->db->join('options_type', 'cart_stock_option.option_id = options_type.opt_var_id');
        $this->db->where('options_type.opt_id',$opt_id);
        $this->db->where('cart_stock.product_id',$product_id);
        $this->db->order_by('status','DESC');
        $this->db->group_by('options_type.opt_var_id');

        $query = $this->db->get();

        $categories=$query->result();

        return $categories;

    }

    public function getHomeUserwishListSub($id='',$user_id='')
    {
        $this->db->select('COUNT(cart_movetowishlist.move_id) AS wish_list');
        $this->db->from('cart_movetowishlist');
        $this->db->where('cart_movetowishlist.stock_id',$id);
        $this->db->where('cart_movetowishlist.user_id',$user_id);
        $this->db->where('cart_movetowishlist.status',1);
        $query = $this->db->get();

        return $query->result_array();
    }

    public function getProductIdWisefeatureTxtSub($id='')
    {
        $this->db->select('cart_feature_group.group_name,cart_feature.display_name as name,cart_stock_feature_txt.feature_p_id');
        $this->db->from('cart_stock_feature_txt');
        $this->db->join('cart_feature', 'cart_stock_feature_txt.feature_p_id = cart_feature.id');
        $this->db->join('cart_feature_group', 'cart_feature.f_grp_id = cart_feature_group.grp_id');
        $this->db->where('cart_stock_feature_txt.product_id',$id);
        $parent = $this->db->get();
        $categories = $parent->result();

        $i=0;

        foreach($categories as $p_cat){

            $categories[$i]->feature_varriant = $this->getProductIdWisefeatureTxtSubSub($p_cat->feature_p_id);

            $i++;
        }
        
        return $categories;
    }

     public function getProductIdWisefeatureTxtSubSub($id='')
    {
        $this->db->select('cart_stock_feature_txt.feature_txt');
        $this->db->from('cart_stock_feature_txt');
        $this->db->where('cart_stock_feature_txt.feature_p_id',$id);
        $query = $this->db->get();

        return $query->result_array();
          
    }


    public function getProductIdWiseListfeatureSub($id='')
    {
   
        $this->db->select('cart_feature_group.group_name,cart_feature.name as display_name,cart_stock_feature.feature_id');
        $this->db->from('cart_stock_feature');
        $this->db->join('cart_feature_variant', 'cart_stock_feature.feature_id = cart_feature_variant.f_var_id');
        $this->db->join('cart_feature', 'cart_feature_variant.f_id = cart_feature.id');
        $this->db->join('cart_feature_group', 'cart_feature.f_grp_id = cart_feature_group.grp_id');
        $this->db->where('cart_stock_feature.product_id',$id);

        $parent = $this->db->get();

        $categories = $parent->result();

        $i=0;

        foreach($categories as $p_cat){

            $categories[$i]->feature_varriant = $this->getFeatureWiseVariantSub($p_cat->feature_id);

            $i++;
        }
        
        return $categories;

    }

    public function getFeatureWiseVariantSub($id='')
    {
        $this->db->select('cart_feature_variant.variants_name');
        $this->db->from('cart_feature_variant');
        $this->db->where('cart_feature_variant.f_var_id',$id);
        $this->db->order_by('cart_feature_variant.variants_name','ASC');
        $query = $this->db->get();

        return $query->result_array();
          
    }

    public function getProductIdWiseListHighlightSub($id='')
    {
        $this->db->select('cart_highlights.highlights');
        $this->db->from('cart_highlights');
        $this->db->where('cart_highlights.product_id',$id);
        $this->db->order_by('cart_highlights.id','desc');
        $query = $this->db->get();

        return $query->result_array();
    }
  
    public function getProductIdWiseListImageSub($id='')
    {
   
        $this->db->select('cart_product_image.id,cart_product_image.image');
        $this->db->from('cart_product_image');
        $this->db->where('cart_product_image.stock_id',$id);
        $query = $this->db->get();

        return $query->result_array();
          
    }

    public function getProductIdWiseRatingSub($id='')
    {
   
        $this->db->select('COUNT(cart_rating.review) AS review_count,COALESCE(SUM(cart_rating.rating_score), 0) AS rating_count,ROUND(AVG(cart_rating.rating_score),1) as average');
        $this->db->from('cart_rating');
        $this->db->where('cart_rating.stock_id',$id);
        $parent = $this->db->get();

        $categories = $parent->result();

        $i=0;

        foreach($categories as $p_cat){

            $avg=$p_cat->average;

            $categories[$i]->review = $this->getProductRateReviewSub($id);

            $i++;
        }
    
        return $categories;

    }

    public function getProductRateReviewSub($id='')
    {
   
        $this->db->select("cart_rating.review,cart_rating.rating_score,DATE_FORMAT(cart_rating.date_rated,'%d %b,%Y') AS rating_date,user_registration.user_name");
        $this->db->from('cart_rating');
        $this->db->join('user_registration', 'cart_rating.user_id = user_registration.id');
        $this->db->where('cart_rating.stock_id',$id);
        $query = $this->db->get();

        return $query->result_array();
          
    }

    public function getProductRategrpSub($id='')
    {
   
        $this->db->select('cart_rating.rating_score,COUNT(cart_rating.rating_score) AS count');
        $this->db->from('cart_rating');
        $this->db->group_by('cart_rating.rating_score');
        $this->db->where('cart_rating.stock_id',$id);
        $query = $this->db->get();

        return $query->result_array();

    }

    public function getProductIdWiseLikeSub($id='',$user_id='')
    {

        $this->db->select('COUNT(cart_likes.stock_id) AS product_like');
        $this->db->from('cart_likes');
        $this->db->where('cart_likes.stock_id',$id);
        $parent = $this->db->get();

        $categories = $parent->result();

        $i=0;

        foreach($categories as $p_cat){

            $categories[$i]->like = $this->getUserWiseLikeSub($id,$user_id);

            $i++;
        }
    
        return $categories;

    }

    public function getUserWiseLikeSub($id='',$user_id='')
    {
   
        $this->db->select('COUNT(cart_likes.user_id) AS user_like');
        $this->db->from('cart_likes');
        $this->db->where('cart_likes.user_id',$user_id);
        $this->db->where('cart_likes.stock_id',$id);
        $query = $this->db->get();

        return $query->result_array();
          

    }

    public function getStockCartStatus($user_id='',$stock_id='') {

        $this->db->where('user_id',$user_id);
        $this->db->where('stock_id',$stock_id);
        $query = $this->db->get('sm_cart_addtocart');

        $res=$query->num_rows();

        return $res;
    }

    public function getProductOnlinePayList($id='',$seller_id='')
    {
        $this->db->select('sm_cart_addtocart.payment_mode as pay_mode,cart_stock.id,sm_cart_addtocart.id as cart_id,sm_cart_addtocart.user_id,cart_stock.price,sm_cart_addtocart.qty,cart_stock.list_price,cart_stock.discount');
        $this->db->from('cart_stock');
        $this->db->join('sm_cart_addtocart', 'cart_stock.id = sm_cart_addtocart.stock_id');
        $this->db->where('sm_cart_addtocart.user_id',$id);
        $this->db->where('sm_cart_addtocart.seller_id',$seller_id);

        //$this->db->where('sm_cart_addtocart.payment_mode','online_pay');

        $query = $this->db->get();

        $categories = $query->result_array();

        return $categories;
    }

    public function getProductGroupCartList($id='',$seller_id='')
    {
        $this->db->select('SUM(cart_stock.list_price * sm_cart_addtocart.qty) AS Total_sale,sm_cart_addtocart.payment_mode as pay_mode');
        $this->db->from('cart_product');
        $this->db->join('cart_stock', 'cart_product.id = cart_stock.product_id');
        $this->db->join('sm_cart_addtocart', 'cart_stock.id = sm_cart_addtocart.stock_id');
        $this->db->join('register', 'cart_product.reg_id = register.reg_id');
        $this->db->where('sm_cart_addtocart.user_id',$id);
        $this->db->where('sm_cart_addtocart.seller_id',$seller_id);
        $this->db->order_by('sm_cart_addtocart.id','desc');
        $this->db->group_by('pay_mode');

        $query = $this->db->get();

        $categories = $query->result_array();

        return $categories;
    }

    public function getProductCartList($id='',$seller_id='')
    {
        $this->db->select('cart_stock.id,sm_cart_addtocart.id as cart_id,sm_cart_addtocart.user_id,cart_product.product_name,cart_stock.stock_name,cart_stock.price,sm_cart_addtocart.qty,cart_stock.list_price,cart_stock.stock,cart_stock.discount,register.reg_id,register.bus_name,register.crop_image,register.pay_in_store,register.cash_on_del,register.online_pay,sm_cart_addtocart.payment_mode as pay_mode');
        $this->db->from('cart_product');
        $this->db->join('cart_stock', 'cart_product.id = cart_stock.product_id');
        $this->db->join('sm_cart_addtocart', 'cart_stock.id = sm_cart_addtocart.stock_id');
        $this->db->join('register', 'cart_product.reg_id = register.reg_id');
        $this->db->where('sm_cart_addtocart.user_id',$id);
        $this->db->where('sm_cart_addtocart.seller_id',$seller_id);
        $this->db->order_by('sm_cart_addtocart.id','desc');

        $query = $this->db->get();

        $categories = $query->result_array();

        $i=0;
       
        foreach($categories as $p_cat) {

            $categories[$i]['image'] = $this->getImageDataSub($p_cat['id']);

            $i++;
        }

        return $categories;
    }

    public function getAddressCount($id='',$seller_id='')
    {
        $this->db->select('user_delivery_address.id');
        $this->db->from('user_delivery_address');
        $this->db->where('user_delivery_address.user_id',$id);
        $this->db->where('user_delivery_address.seller_id',$seller_id);

        $query = $this->db->get();

        $categories = $query->num_rows();

        return $categories;
    }

    public function getProductWishList($id='') {
   
        $this->db->select('cart_movetowishlist.move_id,cart_movetowishlist.stock_id,cart_movetowishlist.user_id,
        cart_stock.id,cart_stock.stock_name,cart_stock.price,cart_stock.list_price,cart_stock.discount,
        cart_product.rating,register.bus_name,register.crop_image,cart_product_image.image');
        $this->db->from('cart_product');
        $this->db->join('cart_stock', 'cart_product.id = cart_stock.product_id');
        $this->db->join('cart_movetowishlist', 'cart_stock.id = cart_movetowishlist.stock_id');
        $this->db->join('register', 'cart_product.reg_id = register.reg_id');
        $this->db->join('cart_product_image', 'cart_stock.id = cart_product_image.stock_id');
        $this->db->where('cart_movetowishlist.user_id',$id);
        $this->db->where('cart_movetowishlist.status',1);
        $this->db->group_by('cart_product_image.stock_id');
        $this->db->order_by('cart_movetowishlist.move_id','desc');

        $query = $this->db->get();

        return $query->result_array();
    }
  

    public function deleteCart($user_id,$stock_id){
        
        $delete = $this->db->delete('sm_cart_addtocart',array('user_id'=>$user_id,'stock_id'=>$stock_id));
        return $delete?true:false;
    }

    public function removeAddCart($user_id,$stock_id){
        
        $delete = $this->db->delete('sm_cart_addtocart',array('user_id'=>$user_id,'stock_id'=>$stock_id));
        return $delete?true:false;
    }

    public function deleteWishlist($user_id,$stock_id){
        $delete = $this->db->delete('cart_movetowishlist',array('user_id'=>$user_id,'stock_id'=>$stock_id));
        return $delete?true:false;
    }

    public function getProductSortList($order='',$cat_id='',$latitude='',$longitude='',$radius='',$min_pr='',$max_pr='',$option='',$feature='',$row='') 
    { 

        $query =$this->db->query("SELECT p6.parent_id as parent6_id, p5.parent_id as parent5_id, p4.parent_id as parent4_id, p3.parent_id as parent3_id, p2.parent_id as parent2_id, p1.parent_id as parent_id, p1.cat_id as cat_id, p1.cat_name from cart_category p1 left join cart_category p2 on p2.cat_id = p1.parent_id left join cart_category p3 on p3.cat_id= p2.parent_id left join cart_category p4 on p4.cat_id= p3.parent_id left join cart_category p5 on p5.cat_id= p4.parent_id left join cart_category p6 on p6.cat_id =p5.parent_id where $cat_id in (p1.parent_id, p2.parent_id, p3.parent_id, p4.parent_id, p5.parent_id, p6.parent_id) order by 1, 2, 3, 4, 5");

        $result = $query->result();

        $category= array();
        
        $f=0;
        foreach ($result as $rows) {


           $category[$f]=$rows->cat_id;

           $f++;
        }

        array_unshift($category,$cat_id);

        $comma_list = implode(",", $category);

        if( !empty($option) && !empty($feature) )
        {
            $option = implode(',', $option);
            $feature = implode(',', $feature);

            $cond=" INNER JOIN cart_stock_option ON cart_stock.id=cart_stock_option.comb_id INNER JOIN cart_stock_feature ON z.id=cart_stock_feature.product_id WHERE cart_stock_option.option_id in ($option) AND cart_stock_feature.feature_id in ($feature) AND";
        }

        else if(!empty($option))
        {
            $option = implode(',', $option);

            $cond="INNER JOIN cart_stock_option ON cart_stock.id=cart_stock_option.comb_id WHERE cart_stock_option.option_id in ($option) AND";

        }
           
        else if(!empty($feature))
        {
            $feature = implode(',', $feature);


            $cond="INNER JOIN cart_stock_feature ON z.id=cart_stock_feature.product_id WHERE cart_stock_feature.feature_id in ($feature) AND";
        }

        else
        {
            $cond='WHERE'; 
        }

        if( !empty($min_pr) && !empty($max_pr) )
        {
            $price_condition="AND cart_stock.list_price BETWEEN $min_pr AND $max_pr";
        }
        else
        {
            $price_condition="";
        }

        $row = ($row) * 10;

        $parent = $this->db->query("SELECT id,stock_name,price,list_price,stock,discount,status,product_id,product_name,rating,reg_id,seller_name,seller_image,cat_name,cat_id,description, distance

        FROM (
        SELECT cart_stock.id,cart_stock.stock_name,cart_stock.price,cart_stock.list_price,cart_stock.stock,cart_stock.discount,cart_stock.status,z.reg_id,z.product_name,z.id as product_id,z.rating,z.cat_id,cart_category.cat_name,register.bus_name as seller_name,register.crop_image as seller_image,z.description,$radius,111.045
        * DEGREES(ACOS(COS(RADIANS($latitude))
        * COS(RADIANS(z.latitude))
        * COS(RADIANS($longitude - z.longitude))
        + SIN(RADIANS($latitude))
        * SIN(RADIANS(z.latitude)))) AS distance
        FROM cart_product AS z
        JOIN cart_stock ON z.id=cart_stock.product_id
        JOIN register ON z.reg_id=register.reg_id
        JOIN cart_category ON z.cat_id=cart_category.cat_id
        $cond
        z.latitude
        BETWEEN $latitude  - ($radius / 111.045)
        AND $latitude  + ($radius / 111.045)
        AND z.longitude
        BETWEEN $longitude - ($radius / (111.045 * COS(RADIANS($latitude))))
        AND $longitude + ($radius / (111.045 * COS(RADIANS($latitude))))
        AND z.cat_id IN ($comma_list) 
        AND NOT cart_stock.status=0 
        $price_condition
        GROUP BY cart_stock.id
        ) AS d
        WHERE distance <= $radius
        ORDER BY $order LIMIT $row,10");
        $categories = $parent->result();

        //print_r($this->db->last_query());exit;
     
          $i=0;
        foreach($categories as $p_cat){

            $rating = $this->getProductListByAreaRatingSub($p_cat->id);

            $categories[$i]->rating_product=$rating[0]['average'];

            $categories[$i]->image_name = $this->getProductListByAreaSub($p_cat->id);

            $i++;
        }
        
        return $categories;
    }
  
    public function getProductFilterList($cat_id='',$latitude='',$longitude='',$radius='',$min_price='',$max_price='')
    {

        if( !empty($cat_id) ) {

            $query =$this->db->query("SELECT p6.parent_id as parent6_id, p5.parent_id as parent5_id, p4.parent_id as parent4_id, p3.parent_id as parent3_id, p2.parent_id as parent2_id, p1.parent_id as parent_id, p1.cat_id as cat_id, p1.cat_name from cart_category p1 left join cart_category p2 on p2.cat_id = p1.parent_id left join cart_category p3 on p3.cat_id= p2.parent_id left join cart_category p4 on p4.cat_id= p3.parent_id left join cart_category p5 on p5.cat_id= p4.parent_id left join cart_category p6 on p6.cat_id =p5.parent_id where $cat_id in (p1.parent_id, p2.parent_id, p3.parent_id, p4.parent_id, p5.parent_id, p6.parent_id) order by 1, 2, 3, 4, 5");

            $result = $query->result();

            $category= array();
            
            $f=0;
            foreach ($result as $rows) {


               $category[$f]=$rows->cat_id;

               $f++;
            }

            array_unshift($category,$cat_id);

            $comma_list = implode(",", $category);

            $cat_condition="AND z.cat_id IN($comma_list)";

        }
        else
        {
            $cat_condition="";
        }

        if( !empty($min_price) && !empty($max_price) )
        {

            $cond="AND cart_stock.list_price BETWEEN $min_price AND $max_price";
        }
        else
        {
            $cond=""; 
        }
      
        $parent = $this->db->query("SELECT cat_id,option_id,name,cat_name,seller_name,distance

        FROM (
        SELECT z.cat_id,options.option_id,options.name,cart_category.display_name as cat_name,register.bus_name as seller_name,p.radius,p.distance_unit
        * DEGREES(ACOS(COS(RADIANS(p.latpoint))
        * COS(RADIANS(z.latitude))
        * COS(RADIANS(p.longpoint - z.longitude))
        + SIN(RADIANS(p.latpoint))
        * SIN(RADIANS(z.latitude)))) AS distance
        FROM cart_product AS z
        JOIN cart_stock ON z.id=cart_stock.product_id
        JOIN register ON z.reg_id=register.reg_id
        JOIN cart_category ON z.cat_id=cart_category.cat_id
        JOIN cart_stock_option ON cart_stock.id=cart_stock_option.comb_id
        JOIN options_type ON cart_stock_option.option_id=options_type.opt_var_id
        JOIN options ON options_type.opt_id=options.option_id
        JOIN (   /* these are the query parameters */
        SELECT  $latitude  AS latpoint,  $longitude AS longpoint,
        $radius AS radius,  111.045 AS distance_unit
        ) AS p ON 1=1
        WHERE z.latitude
        BETWEEN p.latpoint  - (p.radius / p.distance_unit)
        AND p.latpoint  + (p.radius / p.distance_unit)
        AND z.longitude
        BETWEEN p.longpoint - (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        AND p.longpoint + (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        AND cart_stock.status=1 
        $cat_condition
        $cond
        GROUP BY options.option_id
        ) AS d
        WHERE distance <= radius
        ORDER BY distance");

        $option = $parent->result();

        $price = $this->getProductMaxSub($cat_id,$latitude,$longitude,$radius,$min_price,$max_price);

        $feature = $this->getProductfeatureFilterSub($cat_id,$latitude,$longitude,$radius,$min_price,$max_price);

        $category = $this->getProductCategoryFilter($cat_id,$latitude,$longitude,$radius,$min_price,$max_price);

        $seller = $this->getProductSelleresFilter($cat_id,$latitude,$longitude,$radius,$min_price,$max_price);

        $option=array("option"=>$option);

        $price=array("price"=>$price);

        $feature=array("feature"=>$feature);

        $category=array("category"=>$category);

        $seller=array("seller"=>$seller);

        $res = array_merge($option,$feature,$price,$category,$seller);

        return $res;
    }


    public function getProductfeatureFilterSub($cat_id='',$latitude='',$longitude='',$radius='',$min_price='',$max_price='')
    {

        $query =$this->db->query("SELECT p6.parent_id as parent6_id, p5.parent_id as parent5_id, p4.parent_id as parent4_id, p3.parent_id as parent3_id, p2.parent_id as parent2_id, p1.parent_id as parent_id, p1.cat_id as cat_id, p1.cat_name from cart_category p1 left join cart_category p2 on p2.cat_id = p1.parent_id left join cart_category p3 on p3.cat_id= p2.parent_id left join cart_category p4 on p4.cat_id= p3.parent_id left join cart_category p5 on p5.cat_id= p4.parent_id left join cart_category p6 on p6.cat_id =p5.parent_id where $cat_id in (p1.parent_id, p2.parent_id, p3.parent_id, p4.parent_id, p5.parent_id, p6.parent_id) order by 1, 2, 3, 4, 5");

        $result = $query->result();

        $category= array();
        
        $f=0;
        foreach ($result as $rows) {


           $category[$f]=$rows->cat_id;

           $f++;
        }

        array_unshift($category,$cat_id);

        $comma_list = implode(",", $category);

        if( !empty($min_price) && !empty($max_price) )
        {

            $cond="AND cart_stock.list_price BETWEEN $min_price AND $max_price";
        }
        else
        {
            $cond=""; 
        }
      
        $parent = $this->db->query("SELECT cat_id,id,name, distance

        FROM (
        SELECT z.cat_id,cart_feature.id,cart_feature.display_name as name,p.radius,p.distance_unit
        * DEGREES(ACOS(COS(RADIANS(p.latpoint))
        * COS(RADIANS(z.latitude))
        * COS(RADIANS(p.longpoint - z.longitude))
        + SIN(RADIANS(p.latpoint))
        * SIN(RADIANS(z.latitude)))) AS distance
        FROM cart_product AS z
        INNER JOIN cart_stock ON z.id=cart_stock.product_id
        INNER JOIN cart_stock_feature ON z.id=cart_stock_feature.product_id
        INNER JOIN cart_feature_variant ON cart_stock_feature.feature_id=cart_feature_variant.f_var_id
        INNER JOIN cart_feature ON cart_feature_variant.f_id=cart_feature.id
        JOIN (   /* these are the query parameters */
        SELECT  $latitude  AS latpoint,  $longitude AS longpoint,
        $radius AS radius,  111.045 AS distance_unit
        ) AS p ON 1=1
        WHERE z.latitude
        BETWEEN p.latpoint  - (p.radius / p.distance_unit)
        AND p.latpoint  + (p.radius / p.distance_unit)
        AND z.longitude
        BETWEEN p.longpoint - (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        AND p.longpoint + (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        AND z.cat_id IN ($comma_list)
        AND NOT cart_stock.status=0 
        $cond
        GROUP BY cart_feature.id
        ) AS d
        WHERE distance <= radius
        ORDER BY distance");

        $res = $parent->result();

        return $res;
    }
   
    public function getProductMaxSub($cat_id='',$latitude='',$longitude='',$radius='',$min_price='',$max_price='') {

        $query =$this->db->query("SELECT p6.parent_id as parent6_id, p5.parent_id as parent5_id, p4.parent_id as parent4_id, p3.parent_id as parent3_id, p2.parent_id as parent2_id, p1.parent_id as parent_id, p1.cat_id as cat_id, p1.cat_name from cart_category p1 left join cart_category p2 on p2.cat_id = p1.parent_id left join cart_category p3 on p3.cat_id= p2.parent_id left join cart_category p4 on p4.cat_id= p3.parent_id left join cart_category p5 on p5.cat_id= p4.parent_id left join cart_category p6 on p6.cat_id =p5.parent_id where $cat_id in (p1.parent_id, p2.parent_id, p3.parent_id, p4.parent_id, p5.parent_id, p6.parent_id) order by 1, 2, 3, 4, 5");

        $result = $query->result();

        $category= array();
        
        $f=0;
        foreach ($result as $rows) {


           $category[$f]=$rows->cat_id;

           $f++;
        }

        array_unshift($category,$cat_id);

        $comma_list = implode(",", $category);

        if( !empty($min_price) && !empty($max_price) )
        {

            $cond="AND cart_stock.list_price BETWEEN $min_price AND $max_price";
        }
        else
        {
            $cond=""; 
        }
   
         $parent = $this->db->query("SELECT LargestPrice,SmallestPrice,distance

        FROM (
        SELECT MAX(cart_stock.list_price) AS LargestPrice,MIN(cart_stock.list_price) AS SmallestPrice,p.radius,p.distance_unit
        * DEGREES(ACOS(COS(RADIANS(p.latpoint))
        * COS(RADIANS(z.latitude))
        * COS(RADIANS(p.longpoint - z.longitude))
        + SIN(RADIANS(p.latpoint))
        * SIN(RADIANS(z.latitude)))) AS distance
        FROM cart_product AS z
        INNER JOIN cart_stock ON z.id=cart_stock.product_id
        JOIN (   /* these are the query parameters */
        SELECT  $latitude  AS latpoint,  $longitude AS longpoint,
        $radius AS radius,  111.045 AS distance_unit
        ) AS p ON 1=1
        WHERE z.latitude
        BETWEEN p.latpoint  - (p.radius / p.distance_unit)
        AND p.latpoint  + (p.radius / p.distance_unit)
        AND z.longitude
        BETWEEN p.longpoint - (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        AND p.longpoint + (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        AND z.cat_id IN ($comma_list)
        AND cart_stock.status=1
        $cond
        ) AS d
        WHERE distance <= radius
        ORDER BY distance");

        $res = $parent->result();

        return $res;
    }


    public function getProductSelleresFilter($cat_id='',$latitude='',$longitude='',$radius='',$min_price='',$max_price='')
    {

        $query =$this->db->query("SELECT p6.parent_id as parent6_id, p5.parent_id as parent5_id, p4.parent_id as parent4_id, p3.parent_id as parent3_id, p2.parent_id as parent2_id, p1.parent_id as parent_id, p1.cat_id as cat_id, p1.cat_name from cart_category p1 left join cart_category p2 on p2.cat_id = p1.parent_id left join cart_category p3 on p3.cat_id= p2.parent_id left join cart_category p4 on p4.cat_id= p3.parent_id left join cart_category p5 on p5.cat_id= p4.parent_id left join cart_category p6 on p6.cat_id =p5.parent_id where $cat_id in (p1.parent_id, p2.parent_id, p3.parent_id, p4.parent_id, p5.parent_id, p6.parent_id) order by 1, 2, 3, 4, 5");

        $result = $query->result();

        $category= array();
        
        $f=0;
        foreach ($result as $rows) {


           $category[$f]=$rows->cat_id;

           $f++;
        }

        array_unshift($category,$cat_id);

        $comma_list = implode(",", $category);

        if( !empty($min_price) && !empty($max_price) )
        {

            $cond="AND cart_stock.list_price BETWEEN $min_price AND $max_price";
        }
        else
        {
            $cond=""; 
        }
      
        $parent = $this->db->query("SELECT reg_id,bus_name, distance

        FROM (
        SELECT z.reg_id,register.bus_name,p.radius,p.distance_unit
        * DEGREES(ACOS(COS(RADIANS(p.latpoint))
        * COS(RADIANS(z.latitude))
        * COS(RADIANS(p.longpoint - z.longitude))
        + SIN(RADIANS(p.latpoint))
        * SIN(RADIANS(z.latitude)))) AS distance
        FROM cart_product AS z
        JOIN cart_stock ON z.id=cart_stock.product_id
        JOIN register ON z.reg_id=register.reg_id
        JOIN (   /* these are the query parameters */
        SELECT  $latitude  AS latpoint,  $longitude AS longpoint,
        $radius AS radius,  111.045 AS distance_unit
        ) AS p ON 1=1
        WHERE z.latitude
        BETWEEN p.latpoint  - (p.radius / p.distance_unit)
        AND p.latpoint  + (p.radius / p.distance_unit)
        AND z.longitude
        BETWEEN p.longpoint - (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        AND p.longpoint + (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        AND z.cat_id IN ($comma_list)
        AND cart_stock.status=1 
        $cond
        GROUP BY register.reg_id
        ) AS d
        WHERE distance <= radius
        ORDER BY distance");

        $res = $parent->result();

        return $res;
    }

    public function getProductCategoryFilter($cat_id='',$latitude='',$longitude='',$radius='',$min_price='',$max_price='')
    {

        $query =$this->db->query("SELECT p6.parent_id as parent6_id, p5.parent_id as parent5_id, p4.parent_id as parent4_id, p3.parent_id as parent3_id, p2.parent_id as parent2_id, p1.parent_id as parent_id, p1.cat_id as cat_id, p1.cat_name from cart_category p1 left join cart_category p2 on p2.cat_id = p1.parent_id left join cart_category p3 on p3.cat_id= p2.parent_id left join cart_category p4 on p4.cat_id= p3.parent_id left join cart_category p5 on p5.cat_id= p4.parent_id left join cart_category p6 on p6.cat_id =p5.parent_id where $cat_id in (p1.parent_id, p2.parent_id, p3.parent_id, p4.parent_id, p5.parent_id, p6.parent_id) order by 1, 2, 3, 4, 5");

        $result = $query->result();

        $category= array();
        
        $f=0;
        foreach ($result as $rows) {


           $category[$f]=$rows->cat_id;

           $f++;
        }

        array_unshift($category,$cat_id);

        $comma_list = implode(",", $category);

        if( !empty($min_price) && !empty($max_price) )
        {

            $cond="AND cart_stock.list_price BETWEEN $min_price AND $max_price";
        }
        else
        {
            $cond=""; 
        }
      
        $parent = $this->db->query("SELECT cat_id,cat_name, distance

        FROM (
        SELECT z.cat_id,cart_category.cat_name,p.radius,p.distance_unit
        * DEGREES(ACOS(COS(RADIANS(p.latpoint))
        * COS(RADIANS(z.latitude))
        * COS(RADIANS(p.longpoint - z.longitude))
        + SIN(RADIANS(p.latpoint))
        * SIN(RADIANS(z.latitude)))) AS distance
        FROM cart_product AS z
        JOIN cart_stock ON z.id=cart_stock.product_id
        JOIN cart_category ON z.cat_id=cart_category.cat_id
        JOIN (   /* these are the query parameters */
        SELECT  $latitude  AS latpoint,  $longitude AS longpoint,
        $radius AS radius,  111.045 AS distance_unit
        ) AS p ON 1=1
        WHERE z.latitude
        BETWEEN p.latpoint  - (p.radius / p.distance_unit)
        AND p.latpoint  + (p.radius / p.distance_unit)
        AND z.longitude
        BETWEEN p.longpoint - (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        AND p.longpoint + (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        AND z.cat_id IN ($comma_list)
        AND cart_stock.status=1 
        $cond
        GROUP BY cart_category.cat_id
        ) AS d
        WHERE distance <= radius
        ORDER BY cat_id ASC");

        $res = $parent->result();

        return $res;
    }

    public function getImageDataSub($id='') {
   
        $this->db->select("cart_product_image.image");
        $this->db->from('cart_product_image');
        $this->db->where('cart_product_image.stock_id',$id);
        $this->db->order_by('cart_product_image.id','ASC');
        $this->db->limit(1);
        $query = $this->db->get();

        if($query->num_rows() > 0 )
        {

            $image=$query->result_array()[0]['image'];

            return $image;
        }
        else{

            return "no image";

        }

    }

    public function getProductActiveDataRateSub($id='')
    {
            $this->db->select('ROUND(AVG(cart_rating.rating_score),1) as average');
            $this->db->from('cart_rating');
            $this->db->where('cart_rating.stock_id',$id);
            $query = $this->db->get();

            return $query->result_array();
    }

    public function getFilterGetDataList($latitude='',$longitude='',$radius='',$cat_id='',$min_pr='',$max_pr='',$option='',$feature='',$row='') 
    { 

        $query =$this->db->query("SELECT p6.parent_id as parent6_id, p5.parent_id as parent5_id, p4.parent_id as parent4_id, p3.parent_id as parent3_id, p2.parent_id as parent2_id, p1.parent_id as parent_id, p1.cat_id as cat_id, p1.cat_name from cart_category p1 left join cart_category p2 on p2.cat_id = p1.parent_id left join cart_category p3 on p3.cat_id= p2.parent_id left join cart_category p4 on p4.cat_id= p3.parent_id left join cart_category p5 on p5.cat_id= p4.parent_id left join cart_category p6 on p6.cat_id =p5.parent_id where $cat_id in (p1.parent_id, p2.parent_id, p3.parent_id, p4.parent_id, p5.parent_id, p6.parent_id) order by 1, 2, 3, 4, 5");

        $result = $query->result();

        $category= array();
        
        $f=0;
        foreach ($result as $rows) {


           $category[$f]=$rows->cat_id;

           $f++;
        }

        array_unshift($category,$cat_id);

        $comma_list = implode(",", $category);

        if( !empty($option) && !empty($feature) )
        {

            $option = implode(',', $option);
            $feature = implode(',', $feature);

            $cond=" INNER JOIN cart_stock_option ON cart_stock.id=cart_stock_option.comb_id INNER JOIN cart_stock_feature ON z.id=cart_stock_feature.product_id WHERE cart_stock_option.option_id in ($option) AND cart_stock_feature.feature_id in ($feature) AND";
        }

        else if(!empty($option))
        {

            $option = implode(',', $option);

            $cond="INNER JOIN cart_stock_option ON cart_stock.id=cart_stock_option.comb_id WHERE cart_stock_option.option_id in ($option) AND";
        }
           
        else if(!empty($feature))
        {
            $feature = implode(',', $feature);

            $cond="INNER JOIN cart_stock_feature ON z.id=cart_stock_feature.product_id WHERE cart_stock_feature.feature_id in ($feature) AND";
        }

        else
        {
            $cond='WHERE'; 
        }

        if( !empty($min_pr) && !empty($max_pr) )
        {

            $price_condition="AND cart_stock.list_price BETWEEN $min_pr AND $max_pr";
        }
        else
        {
            $price_condition="";
        } 

        $row = ($row) * 10;
    
        $parent = $this->db->query("SELECT id,stock_name,price,list_price,stock,product_id,product_name,discount,status,reg_id,seller_name,seller_image,cat_id,cat_name,description, distance

        FROM (
        SELECT cart_stock.id,cart_stock.stock_name,cart_stock.price,cart_stock.list_price,cart_stock.stock,cart_stock.discount,cart_stock.status,z.id as product_id,z.reg_id,register.bus_name as seller_name,register.crop_image  as seller_image,z.product_name,z.cat_id,cart_category.cat_name,z.description,$radius,111.045
        * DEGREES(ACOS(COS(RADIANS($latitude))
        * COS(RADIANS(z.latitude))
        * COS(RADIANS($longitude - z.longitude))
        + SIN(RADIANS($latitude))
        * SIN(RADIANS(z.latitude)))) AS distance
        FROM cart_product AS z
        JOIN cart_stock ON z.id=cart_stock.product_id
        JOIN register ON z.reg_id=register.reg_id
        JOIN cart_category ON z.cat_id=cart_category.cat_id
        $cond
        z.latitude
        BETWEEN $latitude  - ($radius / 111.045)
        AND $latitude  + ($radius / 111.045)
        AND z.longitude
        BETWEEN $longitude - ($radius / (111.045 * COS(RADIANS($latitude))))
        AND $longitude + ($radius / (111.045 * COS(RADIANS($latitude))))
        AND z.cat_id IN ($comma_list)
        AND cart_stock.status=1 
        $price_condition
        ) AS d

        WHERE distance <= $radius
        ORDER BY distance LIMIT $row,10");

        $categories = $parent->result();

        $i=0;

        foreach($categories as $p_cat) {
            
            $rating = $this->getProductListByAreaRatingSub($p_cat->id);

            $categories[$i]->rating_product=$rating[0]['average'];

            $categories[$i]->image_name = $this->getProductListByAreaSub($p_cat->id);
            
            $i++;
        }
        return $categories;
    }

    public function getTopDealDataList($user_id='',$latitude='',$longitude='',$radius='',$cat_id='')
    {
        if( !empty($cat_id) )
        {
            $query =$this->db->query("SELECT p6.parent_id as parent6_id, p5.parent_id as parent5_id, p4.parent_id as parent4_id, p3.parent_id as parent3_id, p2.parent_id as parent2_id, p1.parent_id as parent_id, p1.cat_id as cat_id, p1.cat_name from cart_category p1 left join cart_category p2 on p2.cat_id = p1.parent_id left join cart_category p3 on p3.cat_id= p2.parent_id left join cart_category p4 on p4.cat_id= p3.parent_id left join cart_category p5 on p5.cat_id= p4.parent_id left join cart_category p6 on p6.cat_id =p5.parent_id where $cat_id in (p1.parent_id, p2.parent_id, p3.parent_id, p4.parent_id, p5.parent_id, p6.parent_id) order by 1, 2, 3, 4, 5");

            $result = $query->result();

            $category= array();
        
            $f=0;

            foreach ($result as $row) {

                $category[$f]=$row->cat_id;

                $f++;
            }

            array_unshift($category,$cat_id);

            $comma_list = implode(",", $category);

            $cat_condition="AND cart_category.cat_id IN($comma_list)";
        }
         else
        {
            $cat_condition="";
        }

        $parent = $this->db->query("SELECT id,price,list_price,stock_name,url_slug,discount,stock,rating,click_count, reg_id,bus_name,cat_id,cat_name,display_name,description,distance



        FROM (
        SELECT cart_stock.id,cart_stock.price,cart_stock.list_price,cart_stock.stock_name,cart_stock.url_slug,cart_stock.discount,cart_stock.stock,z.reg_id,register.bus_name,z.cat_id,cart_category.cat_name,cart_category.display_name,z.rating,z.click_count,z.description,p.radius,p.distance_unit
        * DEGREES(ACOS(COS(RADIANS(p.latpoint))
        * COS(RADIANS(z.latitude))
        * COS(RADIANS(p.longpoint - z.longitude))
        + SIN(RADIANS(p.latpoint))
        * SIN(RADIANS(z.latitude)))) AS distance
        FROM cart_product AS z
        INNER JOIN cart_stock ON z.id=cart_stock.product_id
        INNER JOIN cart_category ON z.cat_id=cart_category.cat_id
        INNER JOIN register ON z.reg_id=register.reg_id
        JOIN (   /* these are the query parameters */
        SELECT  $latitude  AS latpoint,  $longitude AS longpoint,
        $radius AS radius,      111.045 AS distance_unit
        ) AS p ON 1=1
        WHERE z.latitude
        BETWEEN p.latpoint  - (p.radius / p.distance_unit)
        AND p.latpoint  + (p.radius / p.distance_unit)
        AND z.longitude
        BETWEEN p.longpoint - (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        AND p.longpoint + (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        $cat_condition
        AND cart_stock.status=1 
        ORDER BY rating DESC
        LIMIT 4
        ) AS d
        WHERE distance <= radius
        ORDER BY distance");


        $categories = $parent->result();

          $i=0;
        foreach($categories as $p_cat){

            $encrypted_id = base64_encode($p_cat->id . SALT_KEY);

            $link='http://onlister.com/product/'.$p_cat->url_slug.'?OL='.$encrypted_id;

            $categories[$i]->share_link=$link;

            $categories[$i]->cart_status = $this->getStockCartStatusSub($user_id,$p_cat->id);

            $categories[$i]->image_name = $this->getTopDealDataListSub($p_cat->id);

            $i++;
        }
        
        return $categories;    

    }

    public function getTopDealDataListSub($id='')
    {
        $this->db->select('cart_product_image.image');
        $this->db->from('cart_product_image');
        $this->db->group_by('cart_product_image.stock_id');
        $this->db->where('cart_product_image.stock_id',$id);
        $query = $this->db->get();

        return $query->result_array();
    }
  
    public function getRecentlyViewed($id='')
    {
   
            $this->db->select('cart_product.id,cart_product.product_name,cart_product.price,cart_product.list_price,cart_product.discount,cart_product.rating,cart_product_image.image');
            $this->db->from('cart_recently_view');
            $this->db->join('cart_product', 'cart_recently_view.product_id = cart_product.id');
            $this->db->join('cart_product_image','cart_product.id = cart_product_image.product_id');
            $this->db->order_by('cart_recently_view.id','desc');
            $this->db->group_by('cart_product_image.product_id');
            $this->db->where('cart_recently_view.user_id',$id);
            $query = $this->db->get();
            return $query->result_array();
    }

    public function getSuggestedforYou($id='')
    {
   
            $this->db->select('cart_product.id,cart_product.product_name,cart_product.price,cart_product.list_price,cart_product.discount,cart_product.rating');
            $this->db->from('cart_user_mostlook');
            $this->db->join('cart_product', 'cart_user_mostlook.product_id = cart_product.id');
            $this->db->where('cart_user_mostlook.user_id',$id);
            $query = $this->db->get();
            $categories = $query->result();

          $i=0;
        foreach($categories as $p_cat){

            $categories[$i]->products = $this->getSuggestedforYouSub($p_cat->cat_id);

            $i++;
        }
        
        return $categories;  
    }

    public function getSuggestedforYouSub($id='')
    {
   
            $this->db->select('cart_product.id,cart_product.product_name,cart_product.price,cart_product.list_price,cart_product.discount,cart_product.rating,cart_product_image.image');
            $this->db->from('cart_recently_view');
            $this->db->join('cart_product', 'cart_recently_view.product_id = cart_product.id');
            $this->db->join('cart_product_image','cart_product.id = cart_product_image.product_id');
            $this->db->order_by('cart_recently_view.id','desc');
            $this->db->group_by('cart_product_image.product_id');
            $this->db->where('cart_product.cat_id',$id);
            $query = $this->db->get();
            return $query->result_array();
    }

    public function getPriorityBanneraList($latitude='',$longitude='',$radius='',$row='') {

        $row = ($row) * 1;

        $query = $this->db->query("SELECT id,banner_name,image,priority,distance

        FROM (
        SELECT z.id,z.banner_name,z.image,z.priority,p.radius,p.distance_unit
        * DEGREES(ACOS(COS(RADIANS(p.latpoint))
        * COS(RADIANS(z.latitude))
        * COS(RADIANS(p.longpoint - z.longitude))
        + SIN(RADIANS(p.latpoint))
        * SIN(RADIANS(z.latitude)))) AS distance
        FROM cart_banner AS z
        JOIN (   /* these are the query parameters */
        SELECT  $latitude  AS latpoint,  $longitude AS longpoint,
        $radius AS radius,      111.045 AS distance_unit
        ) AS p ON 1=1
        WHERE z.latitude
        BETWEEN p.latpoint  - (p.radius / p.distance_unit)
        AND p.latpoint  + (p.radius / p.distance_unit)
        AND z.longitude
        BETWEEN p.longpoint - (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        AND p.longpoint + (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        ) AS d
        WHERE distance <= radius
        ORDER BY priority ASC LIMIT $row,1");
        
        $categories = $query->result();
        
        return $categories;   
    }
 
    public function getSelleRatingTotalLikeSub($id='') {
   
        $this->db->select('COUNT(cart_seller_likes.seller_id) AS like_count');
        $this->db->from('cart_seller_likes');
        $this->db->where('cart_seller_likes.seller_id',$id);
        $this->db->where('cart_seller_likes.like_status',1);
        $query = $this->db->get();

       return $query->result_array();
    }

    public function getSellerReviewData($id='')
    {
        $this->db->select('cart_seller_review.review_id,cart_seller_review.review,cart_seller_review.date_rated as rating_date,register.reg_id,register.bus_name as seller name,user_registration.user_name,user_registration.prof_image,register.phone,register.crop_image,register.cover_image,cart_seller_review.rating_score');
        $this->db->from('cart_seller_review');
        $this->db->join('register', 'cart_seller_review.seller_id = register.reg_id');
        $this->db->join('user_registration', 'cart_seller_review.user_id = user_registration.id');
        $this->db->order_by('cart_seller_review.review_id','desc');
        $this->db->where('cart_seller_review.seller_id',$id);
        $query = $this->db->get();

        return $query->result_array();
    }

    public function getProductRatingData($id='')
    {
   
        $this->db->select('cart_rating.rating_id,cart_rating.review,cart_rating.rating_score,cart_rating.date_rated as rating_date,cart_stock.id,cart_stock.stock_name,cart_stock.price,cart_stock.list_price,cart_stock.stock,user_registration.user_name');
        $this->db->from('cart_stock');
        $this->db->join('cart_rating', 'cart_stock.id = cart_rating.stock_id');
        $this->db->join('user_registration', 'cart_rating.user_id = user_registration.id');
        $this->db->where('cart_rating.stock_id',$id);
        $this->db->where('cart_stock.status',1); 
        $query = $this->db->get();

         return $query->result_array();
    }

    public function getCategoryViewAllList($user_id='',$latitude='',$longitude='',$radius='')
    {

    $parent = $this->db->query("SELECT cat_id,cat_name,display_name,cat_icon,id,price,list_price,discount,stock_name,stock,rating,click_count, reg_id,bus_name,description, distance

        FROM (
        SELECT MAX(cart_stock.discount) as discount,z.cat_id,cart_category.cat_name,cart_category.display_name,cart_category.cat_icon,cart_stock.id,cart_stock.price,cart_stock.list_price,cart_stock.stock_name,cart_stock.stock,z.reg_id,register.bus_name, z.rating, z.click_count, z.description,p.radius,p.distance_unit
        * DEGREES(ACOS(COS(RADIANS(p.latpoint))
        * COS(RADIANS(z.latitude))
        * COS(RADIANS(p.longpoint - z.longitude))
        + SIN(RADIANS(p.latpoint))
        * SIN(RADIANS(z.latitude)))) AS distance
        FROM cart_product AS z
        JOIN cart_stock ON z.id=cart_stock.product_id
        JOIN cart_category ON z.cat_id=cart_category.cat_id
        JOIN register ON z.reg_id=register.reg_id
        JOIN (   /* these are the query parameters */
        SELECT  $latitude  AS latpoint,  $longitude AS longpoint,
        $radius AS radius,      111.045 AS distance_unit
        ) AS p ON 1=1
        WHERE z.latitude
        BETWEEN p.latpoint  - (p.radius / p.distance_unit)
        AND p.latpoint  + (p.radius / p.distance_unit)
        AND z.longitude
        BETWEEN p.longpoint - (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        AND p.longpoint + (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        AND cart_stock.status=1 
        GROUP BY cat_id
        ) AS d
        WHERE distance <= radius
        ORDER BY discount DESC");

        $categories = $parent->result();

          $i=0;
        foreach($categories as $p_cat){

            $categories[$i]->cart_status = $this->getStockCartStatusSub($user_id,$p_cat->id);

            $categories[$i]->image_name = $this->getCategoryHomeSub($p_cat->id);

            $i++;
        }
        
        return $categories;    
    }

    public function getBestDealViewAllData($row_limit='',$user_id,$latitude='',$longitude='',$radius='',$cat_id='',$data='')
    {

       $min_pr=$data['min_pr'];
        $max_pr=$data['max_pr'];

        $option = implode(',', $data['options']);

        $feature=implode(',', $data['features']);

        $seller=implode(',', $data['seller']);

        if( !empty($cat_id) ) {

            $query =$this->db->query("SELECT p6.parent_id as parent6_id, p5.parent_id as parent5_id, p4.parent_id as parent4_id, p3.parent_id as parent3_id, p2.parent_id as parent2_id, p1.parent_id as parent_id, p1.cat_id as cat_id, p1.cat_name from cart_category p1 left join cart_category p2 on p2.cat_id = p1.parent_id left join cart_category p3 on p3.cat_id= p2.parent_id left join cart_category p4 on p4.cat_id= p3.parent_id left join cart_category p5 on p5.cat_id= p4.parent_id left join cart_category p6 on p6.cat_id =p5.parent_id where $cat_id in (p1.parent_id, p2.parent_id, p3.parent_id, p4.parent_id, p5.parent_id, p6.parent_id) order by 1, 2, 3, 4, 5");

            $result = $query->result();

            $category= array();
            
            $f=0;
            foreach ($result as $rows) {

               $category[$f]=$rows->cat_id;

               $f++;
            }

            array_unshift($category,$cat_id);

            $comma_list = implode(",", $category);

            $cat_condition="AND z.cat_id IN($comma_list)";
        }
        else
        {
            $cat_condition="";
        }


        if( !empty($option) && !empty($feature) )
        {

            $cond=" INNER JOIN cart_stock_option ON cart_stock.id=cart_stock_option.comb_id INNER JOIN cart_stock_feature ON z.id=cart_stock_feature.product_id WHERE cart_stock_option.option_id in ($option) AND cart_stock_feature.feature_id in ($feature) AND";
        }

        else if(!empty($option))
        {

            $cond="INNER JOIN cart_stock_option ON cart_stock.id=cart_stock_option.comb_id WHERE cart_stock_option.option_id in ($option) AND";

        }
           
        else if(!empty($feature))
        {

            $cond="INNER JOIN cart_stock_feature ON z.id=cart_stock_feature.product_id WHERE cart_stock_feature.feature_id in ($feature) AND";
        }

        else
        {
            $cond='WHERE'; 
        }

        if( !empty($min_pr) && !empty($max_pr) )
        {
            $price_condition="AND cart_stock.list_price BETWEEN $min_pr AND $max_pr";
        }
        else
        {
            $price_condition="";
        }

        if(!empty($seller))
        {
            $seller_condition="AND register.reg_id in ($seller)";
        }
        else
        {
            $seller_condition="";
        }

        $row_limit = ($row_limit) * 10;

        $parent = $this->db->query("SELECT id,stock_name,url_slug,price,list_price,stock,discount,status,product_id,product_name,rating,reg_id,seller_name,seller_image,cat_name,cat_id,description, distance

        FROM (
        SELECT cart_stock.id,cart_stock.stock_name,cart_stock.url_slug,cart_stock.price,cart_stock.list_price,cart_stock.stock,cart_stock.discount,cart_stock.status,z.reg_id,z.product_name,z.id as product_id,z.rating,z.cat_id,cart_category.cat_name,register.bus_name as seller_name,register.crop_image as seller_image,z.description,$radius,111.045
        * DEGREES(ACOS(COS(RADIANS($latitude))
        * COS(RADIANS(z.latitude))
        * COS(RADIANS($longitude - z.longitude))
        + SIN(RADIANS($latitude))
        * SIN(RADIANS(z.latitude)))) AS distance
        FROM cart_product AS z
        JOIN cart_stock ON z.id=cart_stock.product_id
        JOIN register ON z.reg_id=register.reg_id
        JOIN cart_category ON z.cat_id=cart_category.cat_id
        $cond
        z.latitude
        BETWEEN $latitude  - ($radius / 111.045)
        AND $latitude  + ($radius / 111.045)
        AND z.longitude
        BETWEEN $longitude - ($radius / (111.045 * COS(RADIANS($latitude))))
        AND $longitude + ($radius / (111.045 * COS(RADIANS($latitude))))
        AND cart_stock.status=1 
        $cat_condition
        $price_condition
        $seller_condition
        ) AS d
        WHERE distance <= $radius
        ORDER BY discount DESC LIMIT $row_limit,10");
        
        $categories = $parent->result();

        $i=0;
        foreach($categories as $p_cat){

            $encrypted_id = base64_encode($p_cat->id . SALT_KEY);

            $link='http://onlister.com/product/'.$p_cat->url_slug.'?OL='.$encrypted_id;

            $categories[$i]->share_link=$link;

            $categories[$i]->cart_status = $this->getStockCartStatusSub($user_id,$p_cat->id);

            $categories[$i]->image_name = $this->getBestDealDataListSub($p_cat->id);

            $i++;
        }
        
        return $categories;    
    }

    public function getBestDealViewAllCount($latitude='',$longitude='',$radius='',$cat_id='',$data='') {

        $min_pr=$data['min_pr'];
        $max_pr=$data['max_pr'];

        $option = implode(',', $data['options']);

        $feature=implode(',', $data['features']);

        $seller=implode(',', $data['seller']);

        if( !empty($cat_id) ) {

            $query =$this->db->query("SELECT p6.parent_id as parent6_id, p5.parent_id as parent5_id, p4.parent_id as parent4_id, p3.parent_id as parent3_id, p2.parent_id as parent2_id, p1.parent_id as parent_id, p1.cat_id as cat_id, p1.cat_name from cart_category p1 left join cart_category p2 on p2.cat_id = p1.parent_id left join cart_category p3 on p3.cat_id= p2.parent_id left join cart_category p4 on p4.cat_id= p3.parent_id left join cart_category p5 on p5.cat_id= p4.parent_id left join cart_category p6 on p6.cat_id =p5.parent_id where $cat_id in (p1.parent_id, p2.parent_id, p3.parent_id, p4.parent_id, p5.parent_id, p6.parent_id) order by 1, 2, 3, 4, 5");

            $result = $query->result();

            $category= array();
            
            $f=0;
            foreach ($result as $rows) {

               $category[$f]=$rows->cat_id;

               $f++;
            }

            array_unshift($category,$cat_id);

            $comma_list = implode(",", $category);

            $cat_condition="AND z.cat_id IN($comma_list)";
        }
        else
        {
            $cat_condition="";
        }


        if( !empty($option) && !empty($feature) )
        {

            $cond=" INNER JOIN cart_stock_option ON cart_stock.id=cart_stock_option.comb_id INNER JOIN cart_stock_feature ON z.id=cart_stock_feature.product_id WHERE cart_stock_option.option_id in ($option) AND cart_stock_feature.feature_id in ($feature) AND";
        }

        else if(!empty($option))
        {

            $cond="INNER JOIN cart_stock_option ON cart_stock.id=cart_stock_option.comb_id WHERE cart_stock_option.option_id in ($option) AND";

        }
           
        else if(!empty($feature))
        {

            $cond="INNER JOIN cart_stock_feature ON z.id=cart_stock_feature.product_id WHERE cart_stock_feature.feature_id in ($feature) AND";
        }

        else
        {
            $cond='WHERE'; 
        }

        if( !empty($min_pr) && !empty($max_pr) )
        {
            $price_condition="AND cart_stock.list_price BETWEEN $min_pr AND $max_pr";
        }
        else
        {
            $price_condition="";
        }

        if(!empty($seller))
        {
            $seller_condition="AND register.reg_id in ($seller)";
        }
        else
        {
            $seller_condition="";
        }

        $parent = $this->db->query("SELECT id,discount,distance

        FROM (
        SELECT cart_stock.id,cart_stock.discount,$radius,111.045
        * DEGREES(ACOS(COS(RADIANS($latitude))
        * COS(RADIANS(z.latitude))
        * COS(RADIANS($longitude - z.longitude))
        + SIN(RADIANS($latitude))
        * SIN(RADIANS(z.latitude)))) AS distance
        FROM cart_product AS z
        JOIN cart_stock ON z.id=cart_stock.product_id
        JOIN register ON z.reg_id=register.reg_id
        JOIN cart_category ON z.cat_id=cart_category.cat_id
        $cond
        z.latitude
        BETWEEN $latitude  - ($radius / 111.045)
        AND $latitude  + ($radius / 111.045)
        AND z.longitude
        BETWEEN $longitude - ($radius / (111.045 * COS(RADIANS($latitude))))
        AND $longitude + ($radius / (111.045 * COS(RADIANS($latitude))))
        AND cart_stock.status=1 
        $cat_condition
        $price_condition
        $seller_condition
        ) AS d
        WHERE distance <= $radius
        ORDER BY discount DESC");
        
        $categories = $parent->num_rows();
        
        return $categories;    
    }
    
    public function getProductWiseCategoryList($seller_id='') {
   
        $this->db->select('cart_category.cat_id,cart_category.display_name as cat_name');
        $this->db->from('cart_category');
        $this->db->join('cart_product', 'cart_category.cat_id = cart_product.cat_id');
        $this->db->join('cart_stock', 'cart_product.id = cart_stock.product_id');
        $this->db->where('cart_product.reg_id',$seller_id);
        $this->db->order_by('cart_stock.discount','DESC');
        $this->db->group_by('cart_product.cat_id');

        $this->db->limit(6);
        $query = $this->db->get();

        if($query->num_rows() > 0 )
        {

            return $query->result_array();
        }
        else{

            return false;

        }
    }
    
    public function getBrandDataList($id)
    {
        $this->db->select('cart_feature_variant.f_var_id as var_id,cart_feature_variant.variants_name as var_name,cart_feature_variant.image');
        $this->db->from('cart_product');
        $this->db->join('cart_stock_feature', 'cart_product.id = cart_stock_feature.product_id');
        $this->db->join('cart_feature_variant', 'cart_stock_feature.feature_id = cart_feature_variant.f_var_id');
        $this->db->where('cart_product.reg_id',$id);
        $this->db->where('cart_feature_variant.f_id',344);
        $this->db->group_by('cart_stock_feature.feature_id');
        $this->db->order_by('rand()');
        $this->db->limit(10);
        $query = $this->db->get();
      
        return $query->result_array();

    }
    
    /*public function getAllproductList($seller_id='',$user_id='',$latitude='',$longitude='',$radius='')
    {
       
        $parent = $this->db->query("SELECT id,price,list_price,stock_name,url_slug,discount,stock,reg_id,bus_name,cat_id,cat_name,description, distance

        FROM (
        SELECT cart_stock.id,cart_stock.price,cart_stock.list_price,cart_stock.discount,cart_stock.stock,cart_stock.stock_name,cart_stock.url_slug,z.reg_id,register.bus_name,z.cat_id,cart_category.cat_name, z.description,p.radius,p.distance_unit
        * DEGREES(ACOS(COS(RADIANS(p.latpoint))
        * COS(RADIANS(z.latitude))
        * COS(RADIANS(p.longpoint - z.longitude))
        + SIN(RADIANS(p.latpoint))
        * SIN(RADIANS(z.latitude)))) AS distance
        FROM cart_product AS z
        INNER JOIN cart_stock ON z.id=cart_stock.product_id
        INNER JOIN cart_category ON z.cat_id=cart_category.cat_id
        INNER JOIN register ON z.reg_id=register.reg_id
        JOIN (   
        SELECT  $latitude  AS latpoint,  $longitude AS longpoint,
        $radius AS radius,111.045 AS distance_unit
        ) AS p ON 1=1
        WHERE z.latitude
        BETWEEN p.latpoint  - (p.radius / p.distance_unit)
        AND p.latpoint  + (p.radius / p.distance_unit)
        AND z.longitude
        BETWEEN p.longpoint - (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        AND p.longpoint + (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        AND cart_stock.status=1 
        AND z.reg_id=$seller_id
        ) AS d
        WHERE distance <= radius
        ORDER BY rand() LIMIT 20");

        $categories = $parent->result();

        $i=0;
        foreach($categories as $p_cat){

            $encrypted_id = base64_encode($p_cat->id . SALT_KEY);

            $link='http://onlister.com/product/'.$p_cat->url_slug.'?OL='.$encrypted_id;

            $categories[$i]->share_link=$link;

            $categories[$i]->cart_status = $this->getStockCartStatusSub($user_id,$p_cat->id);

            $categories[$i]->image_name = $this->getProductImageSub($p_cat->id);

            $i++;
        }
        
        return $categories;    
    }*/
    public function getAllproductList($seller_id='',$user_id='',$latitude='',$longitude='',$radius='')
    {
       
        $parent = $this->db->query("
        SELECT cart_stock.id,cart_stock.price,cart_stock.list_price,cart_stock.discount,cart_stock.stock,cart_stock.stock_name,cart_stock.url_slug,z.reg_id,register.bus_name,z.cat_id,cart_category.cat_name, z.description
        FROM cart_product AS z
        INNER JOIN cart_stock ON z.id=cart_stock.product_id
        INNER JOIN cart_category ON z.cat_id=cart_category.cat_id
        INNER JOIN register ON z.reg_id=register.reg_id
        WHERE z.reg_id=$seller_id
        AND cart_stock.status=1 
        ORDER BY rand() LIMIT 20");

        $categories = $parent->result();

        $i=0;
        foreach($categories as $p_cat){

            $encrypted_id = base64_encode($p_cat->id . SALT_KEY);

            $link='http://onlister.com/product/'.$p_cat->url_slug.'?OL='.$encrypted_id;

            $categories[$i]->share_link=$link;

            $categories[$i]->cart_status = $this->getStockCartStatusSub($user_id,$p_cat->id);

            $categories[$i]->image_name = $this->getProductImageSub($p_cat->id);

            $i++;
        }
        
        return $categories;    
    }
               
}

?>