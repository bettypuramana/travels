<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Notification_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        
        //load database library
        $this->load->database();
    }

    var $table = 'sm_user_notification';
    var $order = array('id' => 'desc');
    
    public function getSingleTokenBySellerData($seller_id='')
    {
        $this->db->select('phone');
        $this->db->from('register_userlist');
        $this->db->where('bus_id',$seller_id);
        $query  = $this->db->get();

        $res = array();

        foreach ($query->result_array() as $key => $bus_phone) {
        
        $this->db->select('seller_fcm_token');
        $this->db->from('otp_table');
        $this->db->where('mobile',$bus_phone['phone']);
        $query  = $this->db->get();

        $data = $query->result_array();

        array_push($res, $data);

        }

        return $res;
    }

    public function updateUserNotification($id) 
    { 

        $data= array('status' => 1);
   
        $this->db->where('user_id',$id);
        $this->db->update('sm_user_notification',$data);
  
        return ($this->db->affected_rows() != 1) ? false : true;
       
    }

    public function updateSellerNotification($id) 
    { 

        $data= array('status' => 1);
   
        $this->db->where('seller_id',$id);
        $this->db->update('seller_notification',$data);
  
        return ($this->db->affected_rows() != 1) ? false : true;
       
    }

    public function getSingleTokenByUserData($user_id='')
    {
        $this->db->select('phone');
        $this->db->from('user_registration');
        $this->db->where('id',$user_id);
        $query  = $this->db->get();

        $this->db->select('fcm_token');
        $this->db->from('otp_table');
        $this->db->where('mobile',$query->result_array()[0]['phone']);
        $query  = $this->db->get();

        $res= $query->result_array();

        return $res;
    }

    public function getTokenByUserData($user_id='')
    {

        $res = array();

        foreach ($user_id as $key => $id) {

            $this->db->select('phone');
            $this->db->from('user_registration');
            $this->db->where('id',$id);
            $query  = $this->db->get();

            $this->db->select('fcm_token');
            $this->db->from('otp_table');
            $this->db->where('mobile',$query->result_array()[0]['phone']);
            $query  = $this->db->get();

            $data= $query->result_array();

            array_push($res, $data);

        }

        return $res;
    }

    public function getTokenBySellerData($seller_id='')
    {

        $res = array();

        foreach ($seller_id as $key => $regid) {

            $this->db->select('phone');
            $this->db->from('register_userlist');
            $this->db->where('bus_id',$regid);
            $query  = $this->db->get();

            foreach ($query->result_array() as $row => $bus_phone) {
        
            $this->db->select('seller_fcm_token');
            $this->db->from('otp_table');
            $this->db->where('mobile',$bus_phone['phone']);
            $query  = $this->db->get();

            $data= $query->result_array();

            array_push($res, $data);

            }


        }

        return $res;
    }

    public function getUserNotificationData($id)
    {

        $this->db->select('sm_user_notification.user_id,sm_user_notification.notification,sm_user_notification.status,sm_user_notification.created');
        $this->db->from($this->table);
        $this->db->where('sm_user_notification.user_id',$id);
        $this->db->order_by('sm_user_notification.id','desc');
        $query = $this->db->get();
      
        return $query->result_array();

    }

    public function getSellerNotificationData($id)
    {
        $this->db->select('seller_notification.seller_id,seller_notification.notification,seller_notification.status,seller_notification.type,seller_notification.created,register.crop_image as image');
        $this->db->from('seller_notification');
         $this->db->join('register', 'seller_notification.seller_id = register.reg_id');
        $this->db->where('seller_notification.seller_id',$id);
        $this->db->order_by('seller_notification.id','desc');
        $query = $this->db->get();
      
        return $query->result_array();

    }

    public function SingleUserNotificationInsert($id) { 
       
        $value = array('notification' => "new one",'user_id' => $id);

        $this->db->insert('sm_user_notification', $value);

        return true;                 
    }


    public function putSellerNotificationInsert($id) { 
       
        $value = array('notification' => "new one",'seller_id' => $id);

        $this->db->insert('seller_notification', $value);

        return true;                 
    }

}

?>
