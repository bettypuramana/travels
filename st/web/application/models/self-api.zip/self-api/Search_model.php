<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Search_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        
        //load database library
        $this->load->database();
    }

    var $table = 'cart_product';
    var $order = array('id' => 'desc');

    public function getSearchAllDataList($user_id='',$seller_id='',$st_name='',$row_limit='',$latitude='',$longitude='',$radius='',$cat_id='')
    {
        $row_limit = ($row_limit) * 10;
        
        
        if( !empty($cat_id) ) {

            $query =$this->db->query("SELECT p6.parent_id as parent6_id, p5.parent_id as parent5_id, p4.parent_id as parent4_id, p3.parent_id as parent3_id, p2.parent_id as parent2_id, p1.parent_id as parent_id, p1.cat_id as cat_id, p1.cat_name from cart_category p1 left join cart_category p2 on p2.cat_id = p1.parent_id left join cart_category p3 on p3.cat_id= p2.parent_id left join cart_category p4 on p4.cat_id= p3.parent_id left join cart_category p5 on p5.cat_id= p4.parent_id left join cart_category p6 on p6.cat_id =p5.parent_id where $cat_id in (p1.parent_id, p2.parent_id, p3.parent_id, p4.parent_id, p5.parent_id, p6.parent_id) order by 1, 2, 3, 4, 5");

            $result = $query->result();

            $category= array();
        
            $f=0;

            foreach ($result as $row) {

                $category[$f]=$row->cat_id;

                $f++;
            }

            array_unshift($category,$cat_id);

            $comma_list = implode(",", $category);

            $cat_condition="AND cart_category.cat_id IN($comma_list)";
        }
        else
        {
            $cat_condition="";
        }
        
        $conditions = array();

        $conditions[] = 'z.product_name  LIKE "%' . $st_name . '%"';
        $conditions[] = 'cart_category.display_name  LIKE "%' . $st_name . '%"';
        $conditions[] = 'cart_stock.stock_name  LIKE "%' . $st_name . '%"';

        if (!empty($st_name)) {

            $sqlStatement = 'AND '. implode(' OR ', $conditions);
        }
        else {
            $sqlStatement = "";
        }

        $query = $this->db->query("
        SELECT cart_stock.id as stock_id,cart_stock.stock_name as name,cart_stock.price,cart_stock.list_price,cart_stock.stock,cart_stock.discount,cart_stock.status,
        z.id,z.cat_id,z.reg_id,z.product_name,z.description as about,100 as type,cart_category.cat_name,register.bus_name,register.location_name,cart_product_image.image
        FROM cart_product AS z
        JOIN cart_stock ON z.id=cart_stock.product_id
        JOIN cart_category ON z.cat_id=cart_category.cat_id
        JOIN register ON z.reg_id=register.reg_id
        JOIN cart_product_image ON cart_stock.id=cart_product_image.stock_id
        WHERE cart_stock.status = 1
        $cat_condition
        $sqlStatement
        GROUP BY cart_product_image.stock_id
        AND register.reg_id   = $seller_id
        LIMIT $row_limit,10");
        
        $categories = $query->result();

        $i=0;

        foreach($categories as $p_cat) {
            
            $categories[$i]->cart_status = $this->getStockCartStatusSub($user_id,$p_cat->stock_id);

            $like = $this->getSearchProductListSub($p_cat->stock_id);

            $categories[$i]->likes=$like[0]['like_count'];

            $bus_like = $this->getSearchShopListSub($p_cat->reg_id);

            $categories[$i]->bus_likes=$bus_like[0]['like_count'];
            
            $categories[$i]->size = $this->getProductOptionSizeSub($p_cat->stock_id);    

            $i++;
        }
      
        return $categories;
    }
    
     public function getProductOptionSizeSub($id='') {

        $this->db->select("options_type.type_name");
        $this->db->from('cart_stock_option');
        $this->db->join('options_type', 'cart_stock_option.option_id = options_type.opt_var_id');
        $this->db->join('options', 'options_type.opt_id = options.option_id');
        $this->db->where('options.display_name','size');
        $this->db->where('cart_stock_option.comb_id',$id);

        $query = $this->db->get();

        if($query->num_rows() > 0 )
        {
            $res=$query->result_array()[0]['type_name'];

            return $res;
        }
        else{

            return "";

        }

        return $categories;

    }
 
    
     public function getStockCartStatusSub($user_id='',$stock_id='') {

        $this->db->where('user_id',$user_id);
        $this->db->where('stock_id',$stock_id);
        $query = $this->db->get('sm_cart_addtocart');

        $res=$query->num_rows();

        return $res;
    }

    public function getImageDataSub($id='') {
   
        $this->db->select("cart_product_image.image");
        $this->db->from('cart_product_image');
        $this->db->where('cart_product_image.stock_id',$id);
        $this->db->order_by('cart_product_image.id','ASC');
        $this->db->limit(1);
        $query = $this->db->get();

        if($query->num_rows() > 0 )
        {

            $image=$query->result_array()[0]['image'];

            return $image;
        }
        else{

            return "no image";

        }
    }

    public function getSearchProductListSub($id='')
    {
        $this->db->select('COUNT(cart_likes.stock_id) AS like_count');
        $this->db->from('cart_likes');
        $this->db->where('cart_likes.stock_id',$id);
        $this->db->where('cart_likes.like_status',1);
        $query = $this->db->get();

        return $query->result_array();
    }

    public function getSearchShopListSub($id='')
    {
        $this->db->select('COUNT(cart_seller_likes.seller_id) AS like_count');
        $this->db->from('cart_seller_likes');
        $this->db->where('cart_seller_likes.seller_id',$id);
        $this->db->where('cart_seller_likes.like_status',1);
        $query = $this->db->get();

        return $query->result_array();
    }

    public function getSearchAllDataListCounter($seller_id='',$st_name='',$latitude='',$longitude='',$radius='',$cat_id='')
    {
        
           if( !empty($cat_id) ) {

            $query =$this->db->query("SELECT p6.parent_id as parent6_id, p5.parent_id as parent5_id, p4.parent_id as parent4_id, p3.parent_id as parent3_id, p2.parent_id as parent2_id, p1.parent_id as parent_id, p1.cat_id as cat_id, p1.cat_name from cart_category p1 left join cart_category p2 on p2.cat_id = p1.parent_id left join cart_category p3 on p3.cat_id= p2.parent_id left join cart_category p4 on p4.cat_id= p3.parent_id left join cart_category p5 on p5.cat_id= p4.parent_id left join cart_category p6 on p6.cat_id =p5.parent_id where $cat_id in (p1.parent_id, p2.parent_id, p3.parent_id, p4.parent_id, p5.parent_id, p6.parent_id) order by 1, 2, 3, 4, 5");

            $result = $query->result();

            $category= array();
        
            $f=0;

            foreach ($result as $row) {

                $category[$f]=$row->cat_id;

                $f++;
            }

            array_unshift($category,$cat_id);

            $comma_list = implode(",", $category);

            $cat_condition="AND cart_category.cat_id IN($comma_list)";
        }
        else
        {
            $cat_condition="";
        }
        
        $conditions = array();

        $conditions[] = 'z.product_name  LIKE "%' . $st_name . '%"';
        $conditions[] = 'cart_category.display_name  LIKE "%' . $st_name . '%"';
        $conditions[] = 'cart_stock.stock_name  LIKE "%' . $st_name . '%"';

        if (!empty($st_name)) {

            $sqlStatement = 'AND '. implode(' OR ', $conditions);
        }
        else {
            $sqlStatement = "";
        }


        $query = $this->db->query("
        SELECT cart_stock.id as stock_id,cart_stock.status,register.reg_id
        FROM cart_product AS z
        JOIN cart_stock ON z.id=cart_stock.product_id
        JOIN cart_category ON z.cat_id=cart_category.cat_id
        JOIN register ON z.reg_id=register.reg_id
        JOIN cart_product_image ON cart_stock.id=cart_product_image.stock_id
         WHERE cart_stock.status = 1
        $cat_condition
        $sqlStatement
        GROUP BY cart_product_image.stock_id
        
        AND register.reg_id   = $seller_id
        ");
        
        $categories = $query->num_rows();
      
        return $categories;
    }

    public function getSearchCatList($seller_id='',$st_name='',$row_page='',$latitude='',$longitude='',$radius='',$cat_id='')
    {
        
        if( !empty($cat_id) ) {

            $conditions_cat = "AND z.cat_id   = $cat_id";

        }

        else {
            
             $conditions_cat = "";
        }
        
        $row_page = ($row_page) * 10;

        $query = $this->db->query("
        SELECT cart_stock.id,cart_stock.price,cart_stock.list_price,cart_stock.discount,cart_stock.stock,cart_stock.stock_name,
        cart_stock.url_slug,cart_stock.status,z.reg_id,register.bus_name,z.cat_id,cart_category.cat_name, z.description
        FROM cart_product AS z
        
        JOIN cart_stock ON z.id=cart_stock.product_id
        JOIN cart_category ON z.cat_id=cart_category.cat_id
        JOIN register ON z.reg_id=register.reg_id
        WHERE cart_stock.status = 1
        
        AND register.reg_id   = $seller_id
        $conditions_cat
         LIMIT $row_page,10");
        
        $categories = $query->result();

        $i=0;

        foreach($categories as $p_cat){

            $categories[$i]->image = $this->getImageDataSub($p_cat->id);

            $i++;
        }

        return $categories;
    }

                   
}

?>