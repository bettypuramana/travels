<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Home_page_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        
        //load database library
        $this->load->database();
    }

    var $table = 'cart_product';
    var $order = array('id' => 'desc');


    public function getHomeBannerList($latitude='',$longitude='',$radius='') {

        $query = $this->db->query("SELECT id,banner_name,image,priority,distance

        FROM (
        SELECT z.id,z.banner_name,z.banner_type,z.type_id,z.image,z.priority,p.radius,p.distance_unit
        * DEGREES(ACOS(COS(RADIANS(p.latpoint))
        * COS(RADIANS(z.latitude))
        * COS(RADIANS(p.longpoint - z.longitude))
        + SIN(RADIANS(p.latpoint))
        * SIN(RADIANS(z.latitude)))) AS distance
        FROM service_banner AS z
        JOIN (   /* these are the query parameters */
        SELECT  $latitude  AS latpoint,  $longitude AS longpoint,
        $radius AS radius,      111.045 AS distance_unit
        ) AS p ON 1=1
        WHERE z.latitude
        BETWEEN p.latpoint  - (p.radius / p.distance_unit)
        AND p.latpoint  + (p.radius / p.distance_unit)
        AND z.longitude
        BETWEEN p.longpoint - (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        AND p.longpoint + (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        ) AS d
        WHERE distance <= radius
        ORDER BY priority ASC");
        
        $categories = $query->result();
        
        return $categories;   
    }

    public function getHomeDataList($seller_id='',$user_id='',$row='',$latitude='',$longitude='',$radius='')
    {

        $row = ($row) * 10;

        $query = $this->db->query("SELECT id,name,url_slug,stock,price,list_price,discount,status,product_id,reg_id,cat_name,product_name,seller_name,phone,about,images,type,created,distance

        FROM (
        SELECT cart_stock.id,cart_stock.stock_name as name,cart_stock.url_slug,cart_stock.price,cart_stock.list_price,cart_stock.stock,cart_stock.discount,cart_stock.status,z.id as product_id,z.cat_id,z.reg_id,cart_category.cat_name,z.product_name,z.description as about,register.crop_image as images,z.type,register.bus_name  as seller_name,register.phone,z.creation_date as created,p.radius,p.distance_unit
        * DEGREES(ACOS(COS(RADIANS(p.latpoint))
        * COS(RADIANS(z.latitude))
        * COS(RADIANS(p.longpoint - z.longitude))
        + SIN(RADIANS(p.latpoint))
        * SIN(RADIANS(z.latitude)))) AS distance
        FROM cart_product AS z
        JOIN cart_stock ON z.id=cart_stock.product_id
        JOIN cart_category ON z.cat_id=cart_category.cat_id
        JOIN register ON z.reg_id=register.reg_id
        JOIN (   /* these are the query parameters */
        SELECT  $latitude  AS latpoint,  $longitude AS longpoint,
        $radius AS radius,  111.045 AS distance_unit
        ) AS p ON 1=1
        WHERE z.latitude
        BETWEEN p.latpoint  - (p.radius / p.distance_unit)
        AND p.latpoint  + (p.radius / p.distance_unit)
        AND z.longitude
        BETWEEN p.longpoint - (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        AND p.longpoint + (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        AND z.reg_id=$seller_id
        AND cart_stock.status=1 
        ) AS d
        WHERE distance <= radius
        ORDER BY id LIMIT $row,10");
        
        $categories = $query->result();

        $i=0;

        foreach($categories as $p_cat) {

            $encrypted_id = base64_encode($p_cat->id . SALT_KEY);

            $link='http://onlister.com/product/'.$p_cat->url_slug.'?OL='.$encrypted_id;

            $categories[$i]->share_link=$link;

            $categories[$i]->cart_status = $this->getStockCartStatusSub($user_id,$p_cat->id);

            $categories[$i]->posted = $this->getLastTimeSub($p_cat->created);

            $user_like = $this->getHomeUserLikeSub($p_cat->reg_id,$user_id);

            $categories[$i]->user_like=$user_like[0]['bus_like'];

            $wish_list = $this->getHomeUserwishListSub($p_cat->id,$user_id);

            $categories[$i]->wish_list=$wish_list[0]['wish_list'];

            $categories[$i]->product_mages= $this->getHomeProductSub($p_cat->id);

            $i++;
        }
      
        return $categories;
    }

    public function getStockCartStatusSub($user_id='',$stock_id='') {

        $this->db->where('user_id',$user_id);
        $this->db->where('stock_id',$stock_id);
        $query = $this->db->get('sm_cart_addtocart');

        $res=$query->num_rows();

        return $res;
    }

    public function getHomeUserLikeSub($id='',$user_id='')
    {
        $this->db->select('COUNT(cart_seller_likes.seller_id) AS bus_like');
        $this->db->from('cart_seller_likes');
        $this->db->where('cart_seller_likes.seller_id',$id);
        $this->db->where('cart_seller_likes.user_id',$user_id);
        $this->db->where('cart_seller_likes.like_status',1);
        $query = $this->db->get();

        return $query->result_array();
    }

    public function getHomeUserwishListSub($id='',$user_id='')
    {
        $this->db->select('COUNT(cart_movetowishlist.move_id) AS wish_list');
        $this->db->from('cart_movetowishlist');
        $this->db->where('cart_movetowishlist.stock_id',$id);
        $this->db->where('cart_movetowishlist.user_id',$user_id);
        $this->db->where('cart_movetowishlist.status',1);
        $query = $this->db->get();

        return $query->result_array();
    }
   
    public function getHomeProductSub($id)
    {
        $this->db->select('cart_product_image.id,cart_product_image.image');
        $this->db->from('cart_product_image');
        $this->db->where('cart_product_image.stock_id',$id);
        $this->db->order_by('cart_product_image.id','asc');
        $query = $this->db->get();

        return $query->result_array();
    }


    public function getLastTimeSub($time_ago='')
    {
        date_default_timezone_set("Asia/Calcutta");   //India time (GMT+5:30)
        $time_ago =  strtotime($time_ago) ? strtotime($time_ago) : $time_ago;
        $time  = time() - $time_ago;

        switch($time):
            // seconds
            case $time <= 60;
                return 'lessthan a minute ago';
            // minutes
            case $time >= 60 && $time < 3600;
                return (round($time/60) == 1) ? 'A minute' : round($time/60).' minutes ago';
            // hours
            case $time >= 3600 && $time < 86400;
                return (round($time/3600) == 1) ? 'A hour ago' : round($time/3600).' hours ago';
            // days
            case $time >= 86400 && $time < 604800;
                return (round($time/86400) == 1) ? 'A day ago' : round($time/86400).' days ago';
            // weeks
            case $time >= 604800 && $time < 2600640;
                return (round($time/604800) == 1) ? 'A week ago' : round($time/604800).' weeks ago';
            // months
            case $time >= 2600640 && $time < 31207680;
                return (round($time/2600640) == 1) ? 'A month ago' : round($time/2600640).' months ago';
            // years
            case $time >= 31207680;
                return (round($time/31207680) == 1) ? 'A year ago' : round($time/31207680).' years ago' ;
        endswitch; 
    }

    public function getHomeTotalCount($seller_id='',$latitude='',$longitude='',$radius='')
    {

        $query = $this->db->query("SELECT id,distance

        FROM (
        SELECT cart_stock.id,p.radius,p.distance_unit
        * DEGREES(ACOS(COS(RADIANS(p.latpoint))
        * COS(RADIANS(z.latitude))
        * COS(RADIANS(p.longpoint - z.longitude))
        + SIN(RADIANS(p.latpoint))
        * SIN(RADIANS(z.latitude)))) AS distance
        FROM cart_product AS z
        JOIN cart_stock ON z.id=cart_stock.product_id
        JOIN cart_category ON z.cat_id=cart_category.cat_id
        JOIN register ON z.reg_id=register.reg_id
        JOIN (   /* these are the query parameters */
        SELECT  $latitude  AS latpoint,  $longitude AS longpoint,
        $radius AS radius,  111.045 AS distance_unit
        ) AS p ON 1=1
        WHERE z.latitude
        BETWEEN p.latpoint  - (p.radius / p.distance_unit)
        AND p.latpoint  + (p.radius / p.distance_unit)
        AND z.longitude
        BETWEEN p.longpoint - (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        AND p.longpoint + (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        AND z.reg_id=$seller_id
        AND cart_stock.status=1 
        ) AS d
        WHERE distance <= radius
        ORDER BY distance");
                
        $result = $query->num_rows();
              
        return $result;
    } 

    public function getHomeBusDataList($user_id,$row='',$latitude='',$longitude='',$radius='')
    {

        $row = ($row) * 10;

        $query = $this->db->query("SELECT reg_id,bus_name,status,phone,about_us as about,crop_image as images,type,created,distance
        FROM (
        SELECT z.reg_id,z.bus_name,z.phone,z.status,z.about_us,z.type,z.crop_image,z.created,p.radius,p.distance_unit
        * DEGREES(ACOS(COS(RADIANS(p.latpoint))
        * COS(RADIANS(z.loc_latitude))
        * COS(RADIANS(p.longpoint - z.loc_longitude))
        + SIN(RADIANS(p.latpoint))
        * SIN(RADIANS(z.loc_latitude)))) AS distance
        FROM register AS z
        JOIN (   /* these are the query parameters */
        SELECT  $latitude  AS latpoint,  $longitude AS longpoint,
        $radius AS radius,  111.045 AS distance_unit
        ) AS p ON 1=1
        WHERE z.loc_latitude
        BETWEEN p.latpoint  - (p.radius / p.distance_unit)
        AND p.latpoint  + (p.radius / p.distance_unit)
        AND z.loc_longitude
        BETWEEN p.longpoint - (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        AND p.longpoint + (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        AND z.status=1 
        ) AS d
        WHERE distance <= radius
        ORDER BY distance LIMIT $row,10");
        
        $categories = $query->result();

        $i=0;

        foreach($categories as $p_cat) {

            $categories[$i]->cover_image = $this->getSellerCoverImageSub($p_cat->reg_id);

            $bus_like = $this->getHomeBusLikeSub($p_cat->reg_id);

            $categories[$i]->bus_like=$bus_like[0]['bus_like'];

            $user_like = $this->getHomeUserLikeSub($p_cat->reg_id,$user_id);

            $categories[$i]->user_like=$user_like[0]['bus_like'];

            $categories[$i]->liked_user = $this->getTwoUserImageSub($p_cat->reg_id);

            $i++;
        }
      
        return $categories;
    }

     public function getSellerCoverImageSub($id='') {
   
        $this->db->select("cart_seller_coverimage.cover_image");
        $this->db->from('cart_seller_coverimage');
        $this->db->where('cart_seller_coverimage.seller_id',$id);
        $this->db->order_by('cart_seller_coverimage.id','ASC');
        $this->db->limit(1);
        $query = $this->db->get();

        if($query->num_rows() > 0 )
        {

            $image=$query->result_array()[0]['cover_image'];

            return $image;
        }
        else{

            return "no image";

        }

    }

    public function getHomeBusLikeSub($id='',$user_id='')
    {
        $this->db->select('COUNT(cart_seller_likes.seller_id) AS bus_like');
        $this->db->from('cart_seller_likes');
        $this->db->where('cart_seller_likes.user_id',$user_id);
        $this->db->where('cart_seller_likes.seller_id',$id);
        $this->db->where('cart_seller_likes.like_status',1);
        $query = $this->db->get();

        return $query->result_array();
    }

    // public function getHomeUserLikeSub($id='')
    // {
    //     $this->db->select('COUNT(cart_seller_likes.seller_id) AS bus_like');
    //     $this->db->from('cart_seller_likes');
    //     $this->db->where('cart_seller_likes.seller_id',$id);
    //     $this->db->where('cart_seller_likes.like_status',1);
    //     $query = $this->db->get();

    //     return $query->result_array();
    // }


    public function getTwoUserImageSub($id='')
    {
        $this->db->select('user_registration.prof_image');
        $this->db->from('cart_seller_likes');
        $this->db->join('user_registration', 'cart_seller_likes.user_id = user_registration.id');
        $this->db->where('cart_seller_likes.seller_id',$id);
        $this->db->where('cart_seller_likes.like_status',1);
        $this->db->where('cart_seller_likes.status',1);
        $this->db->order_by('cart_seller_likes.id','DESC');
        $this->db->limit(2);
        $query = $this->db->get();

        return $query->result_array();
    }  

    public function getProductListByArea($seller_id='',$home_id='',$latitude='',$longitude='',$radius='',$row='',$order='',$data='')
    {

        $min_pr=$data['min_pr'];
        $max_pr=$data['max_pr'];

        $option = implode(',', $data['options']);

        $feature=implode(',', $data['features']);

        $seller=implode(',', $data['seller']);
        

        if( !empty($option) && !empty($feature) )
        {

            $cond=" INNER JOIN cart_stock_option ON cart_stock.id=cart_stock_option.comb_id INNER JOIN cart_stock_feature ON z.id=cart_stock_feature.product_id WHERE cart_stock_option.option_id in ($option) AND cart_stock_feature.feature_id in ($feature) AND";
        }

        else if(!empty($option))
        {

            $cond="INNER JOIN cart_stock_option ON cart_stock.id=cart_stock_option.comb_id WHERE cart_stock_option.option_id in ($option) AND";

        }
           
        else if(!empty($feature))
        {

            $cond="INNER JOIN cart_stock_feature ON z.id=cart_stock_feature.product_id WHERE cart_stock_feature.feature_id in ($feature) AND";
        }

        else
        {
            $cond='WHERE'; 
        }

        if( !empty($min_pr) && !empty($max_pr) )
        {
            $price_condition="AND cart_stock.list_price BETWEEN $min_pr AND $max_pr";
        }
        else
        {
            $price_condition="";
        }

        if(!empty($seller))
        {
            $seller_condition="AND register.reg_id in ($seller)";
        }
        else
        {
            $seller_condition="";
        }

        $row = ($row) * 10;

        $parent = $this->db->query("SELECT id,stock_name,price,list_price,stock,discount,status,product_id,product_name,rating,reg_id,seller_name,seller_image,cat_name,cat_id,description, distance

        FROM (
        SELECT cart_stock.id,cart_stock.stock_name,cart_stock.price,cart_stock.list_price,cart_stock.stock,cart_stock.discount,cart_stock.status,z.reg_id,z.product_name,z.id as product_id,z.rating,z.cat_id,cart_category.cat_name,register.bus_name as seller_name,register.crop_image as seller_image,z.description,$radius,111.045
        * DEGREES(ACOS(COS(RADIANS($latitude))
        * COS(RADIANS(z.latitude))
        * COS(RADIANS($longitude - z.longitude))
        + SIN(RADIANS($latitude))
        * SIN(RADIANS(z.latitude)))) AS distance
        FROM cart_product AS z
        JOIN cart_stock ON z.id=cart_stock.product_id
        JOIN register ON z.reg_id=register.reg_id
        JOIN cart_category ON z.cat_id=cart_category.cat_id
        JOIN assign_home_category ON cart_category.cat_id=assign_home_category.cat_id
        $cond
        z.latitude
        BETWEEN $latitude  - ($radius / 111.045)
        AND $latitude  + ($radius / 111.045)
        AND z.longitude
        BETWEEN $longitude - ($radius / (111.045 * COS(RADIANS($latitude))))
        AND $longitude + ($radius / (111.045 * COS(RADIANS($latitude))))
        AND assign_home_category.home_id = $home_id 
        AND assign_home_category.status = 1 
        AND z.reg_id=$seller_id
        AND cart_stock.status=1
        $price_condition
        $seller_condition
        GROUP BY cart_stock.id
        ) AS d
        WHERE distance <= $radius
        ORDER BY $order LIMIT $row,10");
        $categories = $parent->result();
     
        $i=0;
        foreach($categories as $p_cat){

            $rating = $this->getProductListByAreaRatingSub($p_cat->id);

            $categories[$i]->rating_product=$rating[0]['average'];

            $categories[$i]->image_name = $this->getProductListByAreaSub($p_cat->id);

            $i++;
        }
        
        return $categories;
    }

    public function getProductListByAreaRatingSub($id='')
    {
   
        $this->db->select('ROUND(AVG(cart_rating.rating_score),1) as average');
        $this->db->from('cart_rating');
        $this->db->where('cart_rating.stock_id',$id);
        $parent = $this->db->get();

        $categories = $parent->result_array();
    
        return $categories;
    }

    public function getProductListByAreaSub($id='') {
        
        $this->db->select('cart_product_image.image');
        $this->db->from('cart_product_image');
        $this->db->where('cart_product_image.stock_id',$id);
        $query = $this->db->get();

        return $query->result_array();
    }

    public function getProductListByAreaCount($seller_id='',$home_id='',$latitude='',$longitude='',$radius='',$data='')
    {

        $min_pr=$data['min_pr'];
        $max_pr=$data['max_pr'];

        $option = implode(',', $data['options']);

        $feature=implode(',', $data['features']);

        $seller=implode(',', $data['seller']);
        

        if( !empty($option) && !empty($feature) )
        {

            $cond=" INNER JOIN cart_stock_option ON cart_stock.id=cart_stock_option.comb_id INNER JOIN cart_stock_feature ON z.id=cart_stock_feature.product_id WHERE cart_stock_option.option_id in ($option) AND cart_stock_feature.feature_id in ($feature) AND";
        }

        else if(!empty($option))
        {

            $cond="INNER JOIN cart_stock_option ON cart_stock.id=cart_stock_option.comb_id WHERE cart_stock_option.option_id in ($option) AND";

        }
           
        else if(!empty($feature))
        {

            $cond="INNER JOIN cart_stock_feature ON z.id=cart_stock_feature.product_id WHERE cart_stock_feature.feature_id in ($feature) AND";
        }

        else
        {
            $cond='WHERE'; 
        }

        if( !empty($min_pr) && !empty($max_pr) )
        {
            $price_condition="AND cart_stock.list_price BETWEEN $min_pr AND $max_pr";
        }
        else
        {
            $price_condition="";
        }

        if(!empty($seller))
        {
            $seller_condition="AND register.reg_id in ($seller)";
        }
        else
        {
            $seller_condition="";
        }

        $parent = $this->db->query("SELECT id,distance

        FROM (
        SELECT cart_stock.id,$radius,111.045
        * DEGREES(ACOS(COS(RADIANS($latitude))
        * COS(RADIANS(z.latitude))
        * COS(RADIANS($longitude - z.longitude))
        + SIN(RADIANS($latitude))
        * SIN(RADIANS(z.latitude)))) AS distance
        FROM cart_product AS z
        JOIN cart_stock ON z.id=cart_stock.product_id
        JOIN register ON z.reg_id=register.reg_id
        JOIN cart_category ON z.cat_id=cart_category.cat_id
        JOIN assign_home_category ON cart_category.cat_id=assign_home_category.cat_id
        $cond
        z.latitude
        BETWEEN $latitude  - ($radius / 111.045)
        AND $latitude  + ($radius / 111.045)
        AND z.longitude
        BETWEEN $longitude - ($radius / (111.045 * COS(RADIANS($latitude))))
        AND $longitude + ($radius / (111.045 * COS(RADIANS($latitude))))
        AND assign_home_category.home_id = $home_id 
        AND assign_home_category.status = 1
        AND z.reg_id=$seller_id
        AND cart_stock.status=1
        $price_condition
        $seller_condition
        GROUP BY cart_stock.id
        ) AS d
        WHERE distance <= $radius");
        $categories = $parent->num_rows();
        
        return $categories;
    }

    public function getUserCartCountSub($id='')
    {
        $this->db->from('sm_cart_addtocart');
        $this->db->where('sm_cart_addtocart.user_id',$id);
        $query = $this->db->get();

        return $query->num_rows();

    }

    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////



    public function getProductFilterOption($seller_id='',$home_id='',$latitude='',$longitude='',$radius='',$min_price='',$max_price='')
    {

        if( !empty($min_price) && !empty($max_price) )
        {

            $cond="AND cart_stock.list_price BETWEEN $min_price AND $max_price";
        }
        else
        {
            $cond=""; 
        }
      
        $query = $this->db->query("SELECT cat_id,option_id,name,cat_name,seller_name,distance

        FROM (
        SELECT z.cat_id,options.option_id,options.name,cart_category.cat_name,register.bus_name as seller_name,p.radius,p.distance_unit
        * DEGREES(ACOS(COS(RADIANS(p.latpoint))
        * COS(RADIANS(z.latitude))
        * COS(RADIANS(p.longpoint - z.longitude))
        + SIN(RADIANS(p.latpoint))
        * SIN(RADIANS(z.latitude)))) AS distance
        FROM cart_product AS z
        JOIN cart_stock ON z.id=cart_stock.product_id
        JOIN register ON z.reg_id=register.reg_id
        JOIN cart_category ON z.cat_id=cart_category.cat_id
        JOIN assign_home_category ON cart_category.cat_id=assign_home_category.cat_id
        JOIN cart_stock_option ON cart_stock.id=cart_stock_option.comb_id
        JOIN options_type ON cart_stock_option.option_id=options_type.opt_var_id
        JOIN options ON options_type.opt_id=options.option_id
        JOIN (   /* these are the query parameters */
        SELECT  $latitude  AS latpoint,  $longitude AS longpoint,
        $radius AS radius,  111.045 AS distance_unit
        ) AS p ON 1=1
        WHERE z.latitude
        BETWEEN p.latpoint  - (p.radius / p.distance_unit)
        AND p.latpoint  + (p.radius / p.distance_unit)
        AND z.longitude
        BETWEEN p.longpoint - (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        AND p.longpoint + (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        AND assign_home_category.home_id = $home_id 
        AND assign_home_category.status = 1 
        AND cart_stock.status=1
        AND z.reg_id=$seller_id
        $cond
        GROUP BY options.option_id
        ) AS d
        WHERE distance <= radius
        ORDER BY distance");

        $result = $query->result();

        return $result;
    }


    public function getProductFilterFeature($seller_id='',$home_id='',$latitude='',$longitude='',$radius='',$min_price='',$max_price='')
    {

        if( !empty($min_price) && !empty($max_price) )
        {

            $cond="AND cart_stock.list_price BETWEEN $min_price AND $max_price";
        }
        else
        {
            $cond=""; 
        }
      
        $query = $this->db->query("SELECT cat_id,id,name, distance

        FROM (
        SELECT z.cat_id,cart_feature.id,cart_feature.display_name as name,p.radius,p.distance_unit
        * DEGREES(ACOS(COS(RADIANS(p.latpoint))
        * COS(RADIANS(z.latitude))
        * COS(RADIANS(p.longpoint - z.longitude))
        + SIN(RADIANS(p.latpoint))
        * SIN(RADIANS(z.latitude)))) AS distance
        FROM cart_product AS z
        JOIN cart_stock ON z.id=cart_stock.product_id
        JOIN cart_category ON z.cat_id=cart_category.cat_id
        JOIN assign_home_category ON cart_category.cat_id=assign_home_category.cat_id
        JOIN cart_stock_feature ON z.id=cart_stock_feature.product_id
        JOIN cart_feature_variant ON cart_stock_feature.feature_id=cart_feature_variant.f_var_id
        JOIN cart_feature ON cart_feature_variant.f_id=cart_feature.id
        JOIN (   /* these are the query parameters */
        SELECT  $latitude  AS latpoint,  $longitude AS longpoint,
        $radius AS radius,  111.045 AS distance_unit
        ) AS p ON 1=1
        WHERE z.latitude
        BETWEEN p.latpoint  - (p.radius / p.distance_unit)
        AND p.latpoint  + (p.radius / p.distance_unit)
        AND z.longitude
        BETWEEN p.longpoint - (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        AND p.longpoint + (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        AND assign_home_category.home_id = $home_id 
        AND assign_home_category.status = 1 
        AND cart_stock.status=1
        AND z.reg_id=$seller_id
        $cond
        GROUP BY cart_feature.id
        ) AS d
        WHERE distance <= radius
        ORDER BY distance");

        $result = $query->result();

        return $result;
    }
   
    public function getProductFilterPrice($seller_id='',$home_id='',$latitude='',$longitude='',$radius='',$min_price='',$max_price='') {


        if( !empty($min_price) && !empty($max_price) )
        {

            $cond="AND cart_stock.list_price BETWEEN $min_price AND $max_price";
        }
        else
        {
            $cond=""; 
        }
   
        $query = $this->db->query("SELECT LargestPrice,SmallestPrice,distance

        FROM (
        SELECT MAX(cart_stock.list_price) AS LargestPrice,MIN(cart_stock.list_price) AS SmallestPrice,p.radius,p.distance_unit
        * DEGREES(ACOS(COS(RADIANS(p.latpoint))
        * COS(RADIANS(z.latitude))
        * COS(RADIANS(p.longpoint - z.longitude))
        + SIN(RADIANS(p.latpoint))
        * SIN(RADIANS(z.latitude)))) AS distance
        FROM cart_product AS z
        JOIN cart_stock ON z.id=cart_stock.product_id
        JOIN cart_category ON z.cat_id=cart_category.cat_id
        JOIN assign_home_category ON cart_category.cat_id=assign_home_category.cat_id
        JOIN (   /* these are the query parameters */
        SELECT  $latitude  AS latpoint,  $longitude AS longpoint,
        $radius AS radius,  111.045 AS distance_unit
        ) AS p ON 1=1
        WHERE z.latitude
        BETWEEN p.latpoint  - (p.radius / p.distance_unit)
        AND p.latpoint  + (p.radius / p.distance_unit)
        AND z.longitude
        BETWEEN p.longpoint - (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        AND p.longpoint + (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        AND assign_home_category.home_id = $home_id 
        AND assign_home_category.status = 1 
        AND cart_stock.status=1
        AND z.reg_id=$seller_id
        $cond
        ) AS d
        WHERE distance <= radius
        ORDER BY distance");

        $result = $query->result();

        return $result;
    }


    public function getProductFilterSeller($seller_id='',$home_id='',$latitude='',$longitude='',$radius='',$min_price='',$max_price='')
    {

        if( !empty($min_price) && !empty($max_price) )
        {

            $cond="AND cart_stock.list_price BETWEEN $min_price AND $max_price";
        }
        else
        {
            $cond=""; 
        }
      
        $query = $this->db->query("SELECT reg_id,bus_name, distance

        FROM (
        SELECT z.reg_id,register.bus_name,p.radius,p.distance_unit
        * DEGREES(ACOS(COS(RADIANS(p.latpoint))
        * COS(RADIANS(z.latitude))
        * COS(RADIANS(p.longpoint - z.longitude))
        + SIN(RADIANS(p.latpoint))
        * SIN(RADIANS(z.latitude)))) AS distance
        FROM cart_product AS z
        JOIN cart_stock ON z.id=cart_stock.product_id
        JOIN register ON z.reg_id=register.reg_id
        JOIN cart_category ON z.cat_id=cart_category.cat_id
        JOIN assign_home_category ON cart_category.cat_id=assign_home_category.cat_id
        JOIN (   /* these are the query parameters */
        SELECT  $latitude  AS latpoint,  $longitude AS longpoint,
        $radius AS radius,  111.045 AS distance_unit
        ) AS p ON 1=1
        WHERE z.latitude
        BETWEEN p.latpoint  - (p.radius / p.distance_unit)
        AND p.latpoint  + (p.radius / p.distance_unit)
        AND z.longitude
        BETWEEN p.longpoint - (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        AND p.longpoint + (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        AND assign_home_category.home_id = $home_id 
        AND assign_home_category.status = 1 
        AND cart_stock.status=1
        AND z.reg_id=$seller_id
        $cond
        GROUP BY register.reg_id
        ) AS d
        WHERE distance <= radius
        ORDER BY distance");

        $result = $query->result();

        return $result;
    }

    public function getProductFilterCategory($seller_id='',$home_id='',$latitude='',$longitude='',$radius='',$min_price='',$max_price='')
    {

        if( !empty($min_price) && !empty($max_price) )
        {

            $cond="AND cart_stock.list_price BETWEEN $min_price AND $max_price";
        }
        else
        {
            $cond=""; 
        }
      
        $query = $this->db->query("SELECT cat_id,cat_name, distance

        FROM (
        SELECT z.cat_id,cart_category.cat_name,p.radius,p.distance_unit
        * DEGREES(ACOS(COS(RADIANS(p.latpoint))
        * COS(RADIANS(z.latitude))
        * COS(RADIANS(p.longpoint - z.longitude))
        + SIN(RADIANS(p.latpoint))
        * SIN(RADIANS(z.latitude)))) AS distance
        FROM cart_product AS z
        JOIN cart_stock ON z.id=cart_stock.product_id
        JOIN cart_category ON z.cat_id=cart_category.cat_id
        JOIN assign_home_category ON cart_category.cat_id=assign_home_category.cat_id
        JOIN (   /* these are the query parameters */
        SELECT  $latitude  AS latpoint,  $longitude AS longpoint,
        $radius AS radius,  111.045 AS distance_unit
        ) AS p ON 1=1
        WHERE z.latitude
        BETWEEN p.latpoint  - (p.radius / p.distance_unit)
        AND p.latpoint  + (p.radius / p.distance_unit)
        AND z.longitude
        BETWEEN p.longpoint - (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        AND p.longpoint + (p.radius / (p.distance_unit * COS(RADIANS(p.latpoint))))
        AND assign_home_category.home_id = $home_id 
        AND assign_home_category.status = 1 
        AND cart_stock.status=1
        AND z.reg_id=$seller_id
        $cond
        GROUP BY cart_category.cat_id
        ) AS d
        WHERE distance <= radius
        ORDER BY cat_id ASC");

        $result = $query->result();

        return $result;
    }

    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public function getStockIdWiseList($id='',$user_id='')
    {

        $this->db->select('cart_stock.id,cart_stock.stock_name,cart_stock.stock,cart_stock.price,cart_stock.list_price,cart_stock.discount,cart_product.id as product_id,cart_product.cat_id,cart_product.reg_id,cart_product.description,cart_product.warranty,register.bus_name,register.crop_image,register.location_name,register.pay_in_store,register.cash_on_del,register.online_pay');
        $this->db->from('cart_stock');
        $this->db->join('cart_product', 'cart_stock.product_id = cart_product.id');
        $this->db->join('register', 'cart_product.reg_id = register.reg_id');
        $this->db->where('cart_stock.id',$id);
        
        $parent = $this->db->get();
        $categories = $parent->result();

        $i=0;

        foreach($categories as $p_cat) {

            $categories[$i]->cart_count = $this->getUserCartCountSub($user_id);

           // $wish_list = $this->getHomeUserwishListSub($p_cat->id,$user_id);

            //$categories[$i]->wish_list=$wish_list[0]['wish_list'];

            $categories[$i]->feature_name = $this->getProductIdWiseListfeatureSub($p_cat->product_id);

            $categories[$i]->feature_txt = $this->getProductIdWisefeatureTxtSub($p_cat->product_id);

            $categories[$i]->option_name = $this->getProductIdWiseListOptionSub($p_cat->id);

            $categories[$i]->highlights = $this->getProductIdWiseListHighlightSub($p_cat->product_id);

            $categories[$i]->image_name = $this->getProductIdWiseListImageSub($p_cat->id);

            $categories[$i]->rating_product = $this->getProductIdWiseRatingSub($p_cat->id);

            $categories[$i]->rate = $this->getProductRategrpSub($p_cat->id,$user_id);

            $categories[$i]->like_product = $this->getProductIdWiseLikeSub($p_cat->id,$user_id);


            $i++;
        }

        return $categories;
    }


    public function getProductIdWiseListOptionSub($id='')
    {
   
        $this->db->select('cart_stock_option.option_id,options.name');
        $this->db->from('cart_stock_option');
        $this->db->join('options_type', 'cart_stock_option.option_id = options_type.opt_var_id');
        $this->db->join('options', 'options_type.opt_id = options.option_id');
        $this->db->where('cart_stock_option.comb_id',$id);
        $parent = $this->db->get();

        $categories = $parent->result();

        $i=0;

        foreach($categories as $p_cat) {

            $categories[$i]->option_varriant = $this->getOptionWiseVariantSub($p_cat->option_id);

            $i++;
        }
        
        return $categories;
    }

    public function getOptionWiseVariantSub($id='')
    {
        $this->db->select('options_type.type_name');
        $this->db->from('options_type');
        $this->db->where('options_type.opt_var_id',$id);
        $this->db->order_by('type_name','ASC');
        $query = $this->db->get();

        $categories=$query->result();

        return $categories;

    }


    // public function getHomeUserwishListSub($id='',$user_id='')
    // {
    //     $this->db->select('COUNT(cart_movetowishlist.move_id) AS wish_list');
    //     $this->db->from('cart_movetowishlist');
    //     $this->db->where('cart_movetowishlist.stock_id',$id);
    //     $this->db->where('cart_movetowishlist.user_id',$user_id);
    //     $this->db->where('cart_movetowishlist.status',1);
    //     $query = $this->db->get();

    //     return $query->result_array();
    // }

    public function getProductIdWisefeatureTxtSub($id='')
    {
        $this->db->select('cart_feature_group.group_name,cart_feature.display_name as name,cart_stock_feature_txt.feature_p_id');
        $this->db->from('cart_stock_feature_txt');
        $this->db->join('cart_feature', 'cart_stock_feature_txt.feature_p_id = cart_feature.id');
        $this->db->join('cart_feature_group', 'cart_feature.f_grp_id = cart_feature_group.grp_id');
        $this->db->where('cart_stock_feature_txt.product_id',$id);
        $parent = $this->db->get();
        $categories = $parent->result();

        $i=0;

        foreach($categories as $p_cat){

            $categories[$i]->feature_varriant = $this->getProductIdWisefeatureTxtSubSub($p_cat->feature_p_id);

            $i++;
        }
        
        return $categories;
    }

     public function getProductIdWisefeatureTxtSubSub($id='')
    {
        $this->db->select('cart_stock_feature_txt.feature_txt');
        $this->db->from('cart_stock_feature_txt');
        $this->db->where('cart_stock_feature_txt.feature_p_id',$id);
        $query = $this->db->get();

        return $query->result_array();
          
    }


    public function getProductIdWiseListfeatureSub($id='')
    {
   
        $this->db->select('cart_feature_group.group_name,cart_feature.name,cart_stock_feature.feature_id');
        $this->db->from('cart_stock_feature');
        $this->db->join('cart_feature_variant', 'cart_stock_feature.feature_id = cart_feature_variant.f_var_id');
        $this->db->join('cart_feature', 'cart_feature_variant.f_id = cart_feature.id');
        $this->db->join('cart_feature_group', 'cart_feature.f_grp_id = cart_feature_group.grp_id');
        $this->db->where('cart_stock_feature.product_id',$id);

        $parent = $this->db->get();

        $categories = $parent->result();

        $i=0;

        foreach($categories as $p_cat){

            $categories[$i]->feature_varriant = $this->getFeatureWiseVariantSub($p_cat->feature_id);

            $i++;
        }
        
        return $categories;

    }

    public function getFeatureWiseVariantSub($id='')
    {
        $this->db->select('cart_feature_variant.variants_name');
        $this->db->from('cart_feature_variant');
        $this->db->where('cart_feature_variant.f_var_id',$id);
        $this->db->order_by('cart_feature_variant.variants_name','ASC');
        $query = $this->db->get();

        return $query->result_array();
          
    }

    // public function getProductIdWiseListOptionSub($id='')
    // {
   
    //     $this->db->select('cart_stock_option.option_id,options.name');
    //     $this->db->from('cart_stock_option');
    //     $this->db->join('options_type', 'cart_stock_option.option_id = options_type.opt_var_id');
    //     $this->db->join('options', 'options_type.opt_id = options.option_id');
    //     $this->db->where('cart_stock_option.comb_id',$id);
    //     $parent = $this->db->get();

    //     $categories = $parent->result();

    //     $i=0;

    //     foreach($categories as $p_cat) {

    //         $categories[$i]->option_varriant = $this->getOptionWiseVariantSub($p_cat->option_id);

    //         $i++;
    //     }
        
    //     return $categories;
    // }

    // public function getOptionWiseVariantSub($id='')
    // {
    //     $this->db->select('options_type.type_name');
    //     $this->db->from('options_type');
    //     $this->db->where('options_type.opt_var_id',$id);
    //     $this->db->order_by('type_name','ASC');
    //     $query = $this->db->get();

    //     $categories=$query->result();

    //     return $categories;

    // }

    public function getProductIdWiseListHighlightSub($id='')
    {
        $this->db->select('cart_highlights.highlights');
        $this->db->from('cart_highlights');
        $this->db->where('cart_highlights.product_id',$id);
        $this->db->order_by('cart_highlights.id','desc');
        $query = $this->db->get();

        return $query->result_array();
    }
  
    public function getProductIdWiseListImageSub($id='')
    {
   
        $this->db->select('cart_product_image.id,cart_product_image.image');
        $this->db->from('cart_product_image');
        $this->db->where('cart_product_image.stock_id',$id);
        $query = $this->db->get();

        return $query->result_array();
          
    }

    public function getProductIdWiseRatingSub($id='')
    {
   
        $this->db->select('COUNT(cart_rating.review) AS review_count,COALESCE(SUM(cart_rating.rating_score), 0) AS rating_count,ROUND(AVG(cart_rating.rating_score),1) as average');
        $this->db->from('cart_rating');
        $this->db->where('cart_rating.stock_id',$id);
        $parent = $this->db->get();

        $categories = $parent->result();

        $i=0;

        foreach($categories as $p_cat){

            $avg=$p_cat->average;

            $categories[$i]->review = $this->getProductRateReviewSub($id);

            $i++;
        }
       // $avg_value=array('rating'=>$avg);

        //$this->db->where('id',$id);
       // $this->db->update('cart_stock',$avg_value);
    
        return $categories;

    }

    public function getProductRateReviewSub($id='')
    {
   
        $this->db->select("cart_rating.review,cart_rating.rating_score,DATE_FORMAT(cart_rating.date_rated,'%d %b,%Y') AS rating_date,user_registration.user_name");
        $this->db->from('cart_rating');
        $this->db->join('user_registration', 'cart_rating.user_id = user_registration.id');
        $this->db->where('cart_rating.stock_id',$id);
        $query = $this->db->get();

        return $query->result_array();
          
    }

    public function getProductRategrpSub($id='')
    {
   
            $this->db->select('cart_rating.rating_score,COUNT(cart_rating.rating_score) AS count');
            $this->db->from('cart_rating');
            $this->db->group_by('cart_rating.rating_score');
            $this->db->where('cart_rating.stock_id',$id);
            $query = $this->db->get();

           return $query->result_array();
          

    }


    public function getProductIdWiseLikeSub($id='',$user_id='')
    {

        $this->db->select('COUNT(cart_likes.stock_id) AS product_like');
        $this->db->from('cart_likes');
        $this->db->where('cart_likes.stock_id',$id);
        $parent = $this->db->get();

        $categories = $parent->result();

        $i=0;

        foreach($categories as $p_cat){

            $categories[$i]->like = $this->getUserWiseLikeSub($id,$user_id);

            $i++;
        }
    
        return $categories;

    }

    public function getUserWiseLikeSub($id='',$user_id='')
    {
   
            $this->db->select('COUNT(cart_likes.user_id) AS user_like');
            $this->db->from('cart_likes');
            $this->db->where('cart_likes.user_id',$user_id);
            $this->db->where('cart_likes.stock_id',$id);
            $query = $this->db->get();

           return $query->result_array();
          

    }



}
?>